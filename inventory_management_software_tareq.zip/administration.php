<?php 
$_SESSION['module'] = 'Administration';
$module = $_SESSION['module'];
?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];
$role =  $_SESSION['role'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();

$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];


if ($module == 'Administration') { ?>
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<!-- PAGE CONTENT BEGINS -->
			<div class="col-md-1"></div>
			<div class="col-md-10">
				<!-- Header Logo -->
				<div class="col-md-12 header">
					<h3> Administration Module </h3>
				</div>
				<?php if (array_search("product", $access) > -1 || isset($CheckSuperAdmin)) { ?>
					<div class="col-md-2 col-xs-6 ">
						<div class="col-md-12 section20">
							<a href="views/product">
								<div class="logo">
									<i class="menu-icon fa fa-product-hunt"></i>
								</div>
								<div class="textModule">
									Product Entry
								</div>
							</a>
						</div>
					</div>
				<?php } ?>
				<?php if (array_search("category", $access) > -1 || isset($CheckSuperAdmin)) { ?>
					<div class="col-md-2 col-xs-6 ">
						<div class="col-md-12 section20">
							<a href="category">
								<div class="logo">
									<i class="menu-icon fa fa-calendar-plus-o"></i>
								</div>
								<div class="textModule">
									Category Entry
								</div>
							</a>
						</div>
					</div>
				<?php } ?>
				<?php if (array_search("unit", $access) > -1 || isset($CheckSuperAdmin)) { ?>
					<div class="col-md-2 col-xs-6 ">
						<div class="col-md-12 section20">
							<a href="unit">
								<div class="logo">
									<i class="menu-icon fa fa-underline"></i>
								</div>
								<div class="textModule">
									Unit Entry
								</div>
							</a>
						</div>
					</div>
				<?php } ?>
				<?php if (array_search("category", $access) > -1 || isset($CheckSuperAdmin)) { ?>
					<div class="col-md-2 col-xs-6 ">
						<div class="col-md-12 section20">
							<a href="category">
								<div class="logo">
									<i class="menu-icon fa fa-list"></i>
								</div>
								<div class="textModule">
									Category Entry
								</div>
							</a>
						</div>
					</div>
				<?php } ?>
			</div>

			<!-- PAGE CONTENT ENDS -->
		</div><!-- /.col -->
	</div><!-- /.row -->


<?php } ?>
<?php include('include/footer.php');?>