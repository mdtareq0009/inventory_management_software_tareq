<?php 
$_SESSION['module'] = 'Administration';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];
?>



    <div id='category'>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-4 col-lg-4 col-md-offset-4">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Category  Entry</h5>
                        </div>
                        <div class="widget-body" style="background-color: #f1f1f1;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-12">
                                        
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Category Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Category Name" class="form-control" v-model="category.name" required />
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
        <br />
        <div class="row" style="width: 99%; margin: 0 auto;">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="categories" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row }">
                            <tr class="hover-tr">
                                <td>{{ row.name }}</td>
                                <td>
									<?php if($_SESSION['role'] !="General"){?>
                                        <a class="blue" href="javascript:" @click="editCategory(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteCategory(row.id)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
										<?php } ?>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>


<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	new Vue({
		el: '#category',
		data () {
        return {
            category: {
                id            : '',
                name          : '',
                created_by    : '<?php echo $_SESSION['uid']?>',
            },

          

            categories      : [],  

            columns: [
                { label: 'Name', field: 'name', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getCategories();
    },
    methods: {

        getCategories(){
            
            axios.get('post_url/get_categories').then(res=>{
                this.categories = res.data;
            })
        },

        save(){

            this.progress = true;

            let url = 'post_url/store_category';
            let quaryType = 'addCategory';

            if(this.category.id != ''){
                 quaryType = 'updateCategory';
            }
           
            
            let fd = new FormData();
            fd.append('category', JSON.stringify(this.category));
            fd.append('quaryType', JSON.stringify(quaryType));
            axios.post(url, fd).then(res=>{
                    this.progress = false;
                    alert(res.data.message);
					if(res.data.success){
                        this.progress = false;
                        this.clear();
                        this.getCategories();
					}else{
                        this.progress = false;
                    }
                   
               
                
            })
        },

        clear(){
        
            this.category = {
                id             : '',
                name           : '',
                created_by: '<?php echo $_SESSION['uid']?>',
            };
        },
        
     
        editCategory(row){     

            this.category = {
                id        : row.id,
                name      : row.name,
                created_by: '<?php echo $_SESSION['uid']?>',
            }

        },
        deleteCategory(data){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
                }).then((result) => {
                if (result.isConfirmed) {
                    const formData = new FormData();
                    formData.append('id', data);
                   
                    axios.post('post_url/del_category', formData)
                    .then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getCategories();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
	})
</script>

<?php include('include/footer.php');?>