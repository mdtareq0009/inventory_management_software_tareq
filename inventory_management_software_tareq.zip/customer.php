<?php 
$_SESSION['module'] = 'Administration';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];
?>



    <div id='customers'>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Customer  Entry</h5>
                        </div>

                        <div class="widget-body" style="background-color: #f1f1f1;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Customer Code </label>
                                            <div class="col-xs-8">
                                                <input type="text" class="form-control" v-model="customer.customer_code" readonly />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Customer Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Customer Name" class="form-control" v-model="customer.name" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Owner Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Owner Name" class="form-control" v-model="customer.owner_name" />
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-6">

                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Phone </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Phone" class="form-control" v-model="customer.mobile" required />
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Address </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Address" class="form-control" v-model="customer.address"/>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Remark </label>
                                            <div class="col-xs-8">
                                                <input type="text"  placeholder="Remark"  class="form-control" v-model="customer.remark"/>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="customers" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row }">
                            <tr class="hover-tr">
                                <td>{{ row.customer_code }}</td>
                                <td>{{ row.name }}</td>
                                <td>{{ row.owner_name }}</td>
                                <td>{{ row.mobile }}</td>
                                <td>{{ row.address }}</td>
                                <td>{{ row.remark }}</td>
                                <td>
									<?php if($_SESSION['role'] !="General"){?>
                                        <a class="blue" href="javascript:" @click="editCustomer(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteCustomer(row)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
										<?php } ?>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>


<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	new Vue({
		el: '#customers',
		data () {
        return {
            customer: {
                id           : '',
                customer_code: '',
                name         : '',
                address      : '',
                mobile       : '',
                owner_name   : '',
                remark       : '',
                created_by   : '<?php echo $_SESSION['uid']?>',
            },

            customers      : [],

            columns: [
                { label: 'Customer Code', field: 'customer_code', align: 'center'},
                { label: 'Name', field: 'name', align: 'center' },
                { label: 'Owner Name', field: 'owner_name', align: 'center' },
                { label: 'Phone', field: 'mobile', align: 'center' },
                { label: 'address', field: 'address', align: 'center' },
                { label: 'Remark', field: 'remark', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getCustomer();
        this.getCustomerCode();
    },
    methods: {

        getCustomer(){
            axios.get('post_url/get_customers').then(res=>{
                this.customers = res.data;
				
            })
        },

        getCustomerCode(){
            axios.get('post_url/get_customer_code').then(res=>{
                this.customer.customer_code = res.data;
            })
        },
        save(){
            this.progress = true;


            let url = 'post_url/store_customer';
            let quaryType = 'addcustomer';

            if(this.customer.id != ''){
                 quaryType = 'updatecustomer';
            }
           
            let fd = new FormData();
            fd.append('customers', JSON.stringify(this.customer));
            fd.append('quaryType', JSON.stringify(quaryType));
            axios.post(url, fd).then(res=>{
                console.log(res.data);
                    this.progress = false;
                    alert(res.data.message);
					if(res.data.success){
                        this.progress = false;
                        this.clear();
                        this.getCustomerCode();
                        this.getCustomer();
					}else{
                        this.progress = false;
                    }
  
            })
        },
        clear(){
        
            this.customer = {
                id             : '',
                customer_code: '',
                name         : '',
                address      : '',
                mobile       : '',
                owner_name   : '',
                remark       : '',
                created_by   : '<?php echo $_SESSION['uid']?>',
            };
        },
        
     
        editCustomer(row){
            this.customer = {
                id           : row.id,
                customer_code: row.customer_code,
                name         : row.name,
                address      : row.address,
                mobile       : row.mobile,
                owner_name   : row.owner_name,
                remark       : row.remark,
                created_by   :  '<?php echo $_SESSION['uid']?>',
            }

        },
        deleteCustomer(data){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
                }).then((result) => {
                if (result.isConfirmed) {
                    let fd = new FormData();
                    fd.append('data', JSON.stringify(data));
            
                    axios.post('post_url/del_customer', fd).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getCustomerCode();
                        this.getCustomer();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
	})
</script>

<?php include('include/footer.php');?>