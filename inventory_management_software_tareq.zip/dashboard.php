<?php 
$module = $_SESSION['module']??'dashboard'; ?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];



if ($module == 'dashboard' or $module == '') { ?>
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<!-- Header Logo -->
			<div class="col-md-12 header" style="height: 130px;">
			    <h3>Welcome To Inventory Managment System</h3>
				
			</div>
			<div class="col-md-10 col-md-offset-1">
				<div class="col-md-4 col-xs-6 section4">
					<div class="col-md-12 section122" style="background-color:#e1e1ff;" onmouseover="this.style.background = '#d2d2ff'" onmouseout="this.style.background = '#e1e1ff'">
						<a href="module/SalesModule">
							<div class="logo">
								<i class="fa fa-usd"></i>
							</div>
							<div class="textModule">
								Invertory Module
							</div>
						</a>
					</div>
				</div>

				

				<div class="col-md-4 col-xs-6 section4">
					<div class="col-md-12 section122" style="background-color:#e6e6ff;" onmouseover="this.style.background = '#b9b9ff'" onmouseout="this.style.background = '#e6e6ff'">
						<a href="module/Administration">
							<div class="logo">
								<i class="fa fa-cogs"></i>
							</div>
							<div class="textModule">
								Administration
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-4 col-xs-6 section4">
					<div class="col-md-12 section122" style="background-color:#ffe3d7;" onmouseover="this.style.background = '#ffc0a6'" onmouseout="this.style.background = '#ffe3d7'">
						<a href="" id="logOut" class="logOut">
							<div class="logo">
								<i class="fa fa-sign-out"></i>
							</div>
							<div class="textModule">
								LogOut
							</div>
						</a>
					</div>
				</div>
			</div>
			<!-- PAGE CONTENT ENDS -->
		</div><!-- /.col -->
	</div><!-- /.row -->


<?php } ?>
<?php include('include/footer.php');?>