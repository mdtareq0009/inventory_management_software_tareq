<?php
	class cls_admin_users{
		public function con(){
			$dbClass = new dbClass();
			return $dbClass->connection();
		}



		public function get_permission($id){
			$result = $this->con()->query("select * from users where id = '$id'");
			return $result;
		}

		public function get_user($id){
			$result = $this->con()->query("select * from users where id = '$id' and role ='Admin'");
			return $result;
		}
		


		public function user_login($username, $password){
		    
		    $uname = $this->con()->real_escape_string($username); 
			$pname = $this->con()->real_escape_string($password);
			
			$salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi=6^7-$^R9F|GK5J#E6WT;IO[JN';

			$hash = $pname;
			$nhash = md5($hash);
			
			$result = $this->con()->query("
				select * from users where username = '$uname' && password = '$nhash'  && status = 'a'
			");
			
			$count = $result->num_rows;
			if($count == 0){
				return "1|Invalid login";
			}else{
				$row = $result->fetch_assoc();
				session_start();
				$_SESSION['uid'] = $row['id'];
				$_SESSION['fullname'] = $row['name'];
				$_SESSION['username'] = $row['username'];
				$_SESSION['role'] = $row['role'];
				
				return "0|none";
			}
		}
	
		
		
		
	}
?>