<?php
class cls_administrator{
	public function con(){
		$dbClass = new dbClass();
		return $dbClass->connection();
	}

	public function get_user(){
	
		$result = $this->con()->query("SELECT u.*,
            CASE
                WHEN u.status = 'a' THEN 'Active'
                ELSE 'Deactive'
            END as status_text
            from users u
            where u.deleted_at is null")->fetch_all(MYSQLI_ASSOC);

		return $result;
	}

	public function user_reg($data){

		$fullname = $this->con()->real_escape_string($data->name); 
		$username = $this->con()->real_escape_string($data->username);
		$password = $this->con()->real_escape_string($data->password);
		$role = $this->con()->real_escape_string($data->role);
		$created_by =  $this->con()->real_escape_string($data->created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$user_q = $this->con()->query("select id from users where username = '$username'");
		$user_count = $user_q->num_rows;
		if($user_count != 0){
			$res = ['success'=>true, 'message'=>'User already exists ! Plz Try Again.'];
			return "User already exists ! Plz Try Again.";
			return $res;
		}else{
			
			$salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi=6^7-$^R9F|GK5J#E6WT;IO[JN';
			$hash = $password;
			$nhash = md5($hash);
			
			$result = $this->con()->query("insert into users (name, username, password, role, created_by,created_at) values ('$fullname','$username', '$nhash', '$role', '$created_by', '$date')");
			// var_dump($result);
			// exit;
			if($result){
				$res = ['success'=>true, 'message'=>'Successfully register your user !'];
				return $res;
			}
			$res = ['success'=>true, 'message'=>'Error Inserting Data !'];
			return $res;
		}	
	}

	public function user_reg_general($data){

		$fullname = $this->con()->real_escape_string($data->name); 
		$username = $this->con()->real_escape_string($data->username);
		$password = $this->con()->real_escape_string($data->password);
		$role = $this->con()->real_escape_string($data->role);
		$permissions = $this->con()->real_escape_string('["purchase","sales","sale_return","product_list","stock","purchase_return"]');
		$created_by =  1;
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$user_q = $this->con()->query("select id from users where username = '$username'");
		$user_count = $user_q->num_rows;
		if($user_count != 0){
			$res = ['success'=>false, 'message'=>'User already exists ! Plz Try Again.'];
			return "User already exists ! Plz Try Again.";
			return $res;
		}else{
			
			$salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi=6^7-$^R9F|GK5J#E6WT;IO[JN';
			$hash = $password;
			$nhash = md5($hash);
			
			$result = $this->con()->query("insert into users (name, username, password, role, permissions, created_by,created_at) values ('$fullname','$username', '$nhash', '$role', '$permissions', '$created_by', '$date')");
			// var_dump($result);
			// exit;
			if($result){
				$res = ['success'=>true, 'message'=>'Successfully register your user !'];
				return $res;
			}
			$res = ['success'=>false, 'message'=>'Error Inserting Data !'];
			return $res;
		}	
	}

	public function update_reg($data){	
	
		$id = $this->con()->real_escape_string($data->id); 
		$fullname = $this->con()->real_escape_string($data->name); 
		$username = $this->con()->real_escape_string($data->username);
		$role = $this->con()->real_escape_string($data->role);
		$created_by =  $this->con()->real_escape_string($data->created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$password = $this->con()->real_escape_string($data->password);
		
		$user_q = $this->con()->query("select id from users where username = '$username' and id !='$id'");
		$user_count = $user_q->num_rows;
		
		if($user_count != 0){
			$res = ['success'=>true, 'message'=>'User already exists ! Plz Try Again.'];
			return "User already exists ! Plz Try Again.";
			return $res;
		}else{
			
		if(isset($password) && !empty($password)){
			$hash = $password;
			$nhash = md5($hash);
		}else{
			$user_q = $this->con()->query("select password from users where id = '$id'")->fetch_assoc();
			$nhash =$this->con()->real_escape_string($user_q['password']);
		}

		$result = $this->con()->query("update users set
			      name       = '$fullname',
			      username   = '$username',
			      role       = '$role',
			      password   = '$nhash',
			      updated_by = '$created_by',
			      updated_at = '$date'
				  where id   = '$id'
		");

		
			
		if($result){
			$res = ['success'=>true, 'message'=>'Successfully Updateed your user !'];
			return $res;
		}
			$res = ['success'=>true, 'message'=>'Error Inserting Data !'];
			return $res;	
		}	
	}
	public function user_active($id,$status,$created_by){	
	
		$id = $this->con()->real_escape_string($id);
		$status = $this->con()->real_escape_string($status);
		$created_by = $this->con()->real_escape_string($created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));

		$result = $this->con()->query("update users set
			      status     = '$status',
			      updated_by = '$created_by',
			      updated_at = '$date'
				  where id   = '$id'
		");

		if($result){
			$res = ['success'=>true, 'message'=>'Status Updateed your user !'];
			return $res;
		}
		
		$res = ['success'=>true, 'message'=>'Error Inserting Data !'];
		return $res;	
	}
	public function user_access($id){	

		
		$uid = $this->con()->real_escape_string($id); 
		$result = $this->con()->query("select permissions from users where id = '$uid'")->fetch_assoc()['permissions'];
		
		
		return $result;	
	}
	public function user_access_store($id,$access,$created){	

		$id = $this->con()->real_escape_string($id);
		$permissions = $this->con()->real_escape_string($access);
		$created_by = $this->con()->real_escape_string($created);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s')); 
		
		// var_dump($created_by);
		// exit;
		$result = $this->con()->query("update users set
		permissions     = '$permissions',
		updated_by = '$created_by',
		updated_at = '$date'
		where id   = '$id'
		");
		$res = ['success'=>true, 'message'=>'Success'];
		return $res;	
	}
	public function get_product(){
		
		$result = $this->con()->query("SELECT
        	p.*,
			c.name as category_name,
			u.name as unit_name,
			CONCAT(p.name, ' - ', p.product_code) AS display_text
			FROM products p
			LEFT JOIN categories c ON p.category_id = c.id
			LEFT JOIN units u ON p.unit_id = u.id
			WHERE p.deleted_at IS NULL
    		ORDER BY p.id DESC")->fetch_all(MYSQLI_ASSOC);
		return $result;
	}
	public function get_company(){
		
		$result = $this->con()->query("SELECT
        	c.*
			FROM company_profiles c")->fetch_assoc();
		return $result;
	}
	public function get_customer(){
		
		$result = $this->con()->query("SELECT
        	c.*,
			CONCAT(c.name, ' - ', c.customer_code) as display_text
			FROM customers c
			WHERE c.deleted_at IS NULL
    		ORDER BY c.id DESC")->fetch_all(MYSQLI_ASSOC);
		return $result;
	}
	public function get_supplier(){
		
		$result = $this->con()->query("SELECT
        	s.*,
			CONCAT(s.name, ' - ', s.supplier_code) as display_text
			FROM suppliers s
			WHERE s.deleted_at IS NULL
    		ORDER BY s.id DESC")->fetch_all(MYSQLI_ASSOC);
		return $result;
	}
	public function get_category(){
		$result = $this->con()->query("SELECT * from categories where deleted_at IS NULL")->fetch_all(MYSQLI_ASSOC);
		return $result;
	}
	public function get_unit(){
		$result = $this->con()->query("SELECT * from units where deleted_at IS NULL")->fetch_all(MYSQLI_ASSOC);
		return $result;
	}
	public function get_product_code(){
		
		$productCode = "P00001";
        
        $lastProduct = $this->con()->query("SELECT * from products");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'P' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}
	public function get_customer_code(){
		
		$productCode = "C00001";
        
        $lastProduct = $this->con()->query("SELECT * from customers");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'C' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}
	public function get_supplier_code(){
		
		$productCode = "S00001";
        
        $lastProduct = $this->con()->query("SELECT * from suppliers");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'S' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}
	public function store_product($data){
		
			$productcode = $this->con()->real_escape_string($data->product_code); 
			$name = $this->con()->real_escape_string($data->name);
			$category_id = $this->con()->real_escape_string($data->category_id);
			$unit_id = $this->con()->real_escape_string($data->unit_id);
			$sale_price = $this->con()->real_escape_string($data->sale_price);
			$purchase_price = $this->con()->real_escape_string($data->purchase_price);
			$reorder_level = $this->con()->real_escape_string($data->reorder_level);
			$created_by =  $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));

			$products = $this->con()->query("select * from products where name = '$name'");
			$product_count = $products->num_rows;
			if($product_count != 0){
				$res = ['success'=>false, 'message'=>'Product already exists ! Plz Try Again.'];
			
				return $res;
			}else{
				$result = $this->con()->query("insert into products(product_code, name, category_id, unit_id, sale_price, purchase_price, reorder_level,created_by,created_at) values ('$productcode','$name', '$category_id', '$unit_id', '$sale_price', '$purchase_price', '$reorder_level','$created_by','$date')");
				if($result){
					$res = ['success'=>true, 'message'=>'Product Added Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function update_product($data){
		$id             = $this->con()->real_escape_string($data->id);
		$name           = $this->con()->real_escape_string($data->name);
		$category_id    = $this->con()->real_escape_string($data->category_id);
		$unit_id        = $this->con()->real_escape_string($data->unit_id);
		$sale_price     = $this->con()->real_escape_string($data->sale_price);
		$purchase_price = $this->con()->real_escape_string($data->purchase_price);
		$reorder_level  = $this->con()->real_escape_string($data->reorder_level);
		$updated_by     = $this->con()->real_escape_string($data->created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$products = $this->con()->query("select * from products where name = '$name' and id !='$id'");
		$product_count = $products->num_rows;
		if($product_count != 0){
			$res = ['success'=>false, 'message'=>'Product already exists ! Plz Try Again.'];
			
			return $res;
		}else{
			$query = "UPDATE products SET
					name = '$name',
					category_id = '$category_id',
					unit_id = '$unit_id',
					sale_price = '$sale_price',
					purchase_price = '$purchase_price',
					reorder_level = '$reorder_level',
					updated_by = '$updated_by',
					updated_at = '$date'
					WHERE id = '$id'";
					
				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Product Update Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function delete_product($data){

		$id= $this->con()->real_escape_string($data->id);
		$created_by= $this->con()->real_escape_string($data->created_by);
		$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
			
		
	
				$query = "UPDATE products SET
					updated_by = $created_by,
					deleted_at = '$date'
					WHERE id = '$id'";

				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Product Delete Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			
	}
	public function store_category($data){
		
			$name = $this->con()->real_escape_string($data->name);
			$created_by =  $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));

			$products = $this->con()->query("select * from categories where name = '$name'");
			$product_count = $products->num_rows;
			if($product_count != 0){
				$res = ['success'=>false, 'message'=>'Category already exists ! Plz Try Again.'];
			
				return $res;
			}else{
				$result = $this->con()->query("insert into categories(name, created_by,created_at) values ('$name', '$created_by','$date')");
				if($result){
					$res = ['success'=>true, 'message'=>'Category Added Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function update_category($data){
		$id             = $this->con()->real_escape_string($data->id);
		$name           = $this->con()->real_escape_string($data->name);
		$updated_by     = $this->con()->real_escape_string($data->created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$products = $this->con()->query("select * from categories where name = '$name' and id !='$id'");
		$product_count = $products->num_rows;
		if($product_count != 0){
			$res = ['success'=>false, 'message'=>'Category already exists ! Plz Try Again.'];
			
			return $res;
		}else{
			$query = "UPDATE categories SET
					name = '$name',
					updated_by = '$updated_by',
					updated_at = '$date'
					WHERE id = '$id'";
					
				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Category Update Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function delete_category($data){

				$id= $this->con()->real_escape_string($data);
				$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));

				$query = "UPDATE categories SET
					deleted_at = '$date'
					WHERE id = '$id'";

				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Category Delete Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			
	}
	public function store_unit($data){
		
			$name = $this->con()->real_escape_string($data->name);
			$created_by =  $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));

			$products = $this->con()->query("select * from units where name = '$name'");
			$product_count = $products->num_rows;
			if($product_count != 0){
				$res = ['success'=>false, 'message'=>'Unit already exists ! Plz Try Again.'];
			
				return $res;
			}else{
				$result = $this->con()->query("insert into units(name, created_by,created_at) values ('$name', '$created_by','$date')");
				if($result){
					$res = ['success'=>true, 'message'=>'Unit Added Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function update_unit($data){
		$id             = $this->con()->real_escape_string($data->id);
		$name           = $this->con()->real_escape_string($data->name);
		$updated_by     = $this->con()->real_escape_string($data->created_by);
		$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
		
		$products = $this->con()->query("select * from units where name = '$name' and id !='$id'");
		$product_count = $products->num_rows;
		if($product_count != 0){
			$res = ['success'=>false, 'message'=>'Unit already exists ! Plz Try Again.'];
			
			return $res;
		}else{
			$query = "UPDATE units SET
					name = '$name',
					updated_by = '$updated_by',
					updated_at = '$date'
					WHERE id = '$id'";
					
				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Unit Update Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			}	
	}
	public function delete_unit($data){

				$id= $this->con()->real_escape_string($data->id);
				$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));

				$query = "UPDATE units SET
					deleted_at = '$date'
					WHERE id = '$id'";

				$result = $this->con()->query($query);
		
					
				if($result){
					$res = ['success'=>true, 'message'=>'Unit Delete Successfully'];
					return $res;
				}
				$res = ['success'=>false, 'Error Inserting Data !'];
				return $res;
			
	}

	
	public function store_customer($data){
		
		$customer_code = $this->con()->real_escape_string($data->customer_code);
		$name          = $this->con()->real_escape_string($data->name);
		$owner_name    = $this->con()->real_escape_string($data->owner_name);
		$mobile        = $this->con()->real_escape_string($data->mobile);
		$address       = $this->con()->real_escape_string($data->address);
		$remark        = $this->con()->real_escape_string($data->remark);
		$created_by    = $this->con()->real_escape_string($data->created_by);
		$date          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));

		$products = $this->con()->query("select * from customers where name = '$name'");
		$product_count = $products->num_rows;
		if($product_count != 0){
			$res = ['success'=>false, 'message'=>'Customer already exists ! Plz Try Again.'];
		
			return $res;
		}else{
			$result = $this->con()->query("insert into customers(customer_code, name, owner_name, mobile, address, remark,created_by,created_at) values ('$customer_code','$name', 
			'$owner_name', '$mobile', '$address', '$remark', '$created_by','$date')");
			if($result){
				$res = ['success'=>true, 'message'=>'Customer Added Successfully'];
				return $res;
			}
			$res = ['success'=>false, 'Error Inserting Data !'];
			return $res;
		}	
}
public function update_customer($data){
	$id             = $this->con()->real_escape_string($data->id);
	$name          = $this->con()->real_escape_string($data->name);
	$owner_name    = $this->con()->real_escape_string($data->owner_name);
	$mobile        = $this->con()->real_escape_string($data->mobile);
	$address       = $this->con()->real_escape_string($data->address);
	$remark        = $this->con()->real_escape_string($data->remark);
	$updated_by    = $this->con()->real_escape_string($data->created_by);
	$date          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
	
	$products = $this->con()->query("select * from customers where name = '$name' and id !='$id'");
	$product_count = $products->num_rows;
	if($product_count != 0){
		$res = ['success'=>false, 'message'=>'Customer already exists ! Plz Try Again.'];
		
		return $res;
	}else{
		$query = "UPDATE customers SET
				name = '$name',
				owner_name = '$owner_name',
				mobile = '$mobile',
				address = '$address',
				remark = '$remark',
				updated_by = '$updated_by',
				updated_at = '$date'
				WHERE id = '$id'";
				
			$result = $this->con()->query($query);
	
				
			if($result){
				$res = ['success'=>true, 'message'=>'Customer Update Successfully'];
				return $res;
			}
			$res = ['success'=>false, 'Error Inserting Data !'];
			return $res;
		}	
}
		public function delete_customer($data){

			$id= $this->con()->real_escape_string($data->id);
			$created_by= $this->con()->real_escape_string($data->created_by);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
				
			

					$query = "UPDATE customers SET
						updated_by = $created_by,
						deleted_at = '$date'
						WHERE id = '$id'";

					$result = $this->con()->query($query);
			
						
					if($result){
						$res = ['success'=>true, 'message'=>'Customer Delete Successfully'];
						return $res;
					}
					$res = ['success'=>false, 'Error Inserting Data !'];
					return $res;
				
		}
	public function store_supplier($data){
		
		$supplier_code = $this->con()->real_escape_string($data->supplier_code);
		$name          = $this->con()->real_escape_string($data->name);
		$owner_name    = $this->con()->real_escape_string($data->owner_name);
		$mobile        = $this->con()->real_escape_string($data->mobile);
		$address       = $this->con()->real_escape_string($data->address);
		$remark        = $this->con()->real_escape_string($data->remark);
		$created_by    = $this->con()->real_escape_string($data->created_by);
		$date          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));

		$products = $this->con()->query("select * from suppliers where name = '$name'");
		$product_count = $products->num_rows;
		if($product_count != 0){
			$res = ['success'=>false, 'message'=>'Supplier already exists ! Plz Try Again.'];
		
			return $res;
		}else{
			$result = $this->con()->query("insert into suppliers(supplier_code, name, owner_name, mobile, address, remark,created_by,created_at) values ('$supplier_code','$name', 
			'$owner_name', '$mobile', '$address', '$remark', '$created_by','$date')");
			if($result){
				$res = ['success'=>true, 'message'=>'Supplier Added Successfully'];
				return $res;
			}
			$res = ['success'=>false, 'Error Inserting Data !'];
			return $res;
		}	
}
public function update_supplier($data){
	$id             = $this->con()->real_escape_string($data->id);
	$name          = $this->con()->real_escape_string($data->name);
	$owner_name    = $this->con()->real_escape_string($data->owner_name);
	$mobile        = $this->con()->real_escape_string($data->mobile);
	$address       = $this->con()->real_escape_string($data->address);
	$remark        = $this->con()->real_escape_string($data->remark);
	$updated_by    = $this->con()->real_escape_string($data->created_by);
	$date          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
	
	$products = $this->con()->query("select * from suppliers where name = '$name' and id !='$id'");
	$product_count = $products->num_rows;
	if($product_count != 0){
		$res = ['success'=>false, 'message'=>'Supplier already exists ! Plz Try Again.'];
		
		return $res;
	}else{
		$query = "UPDATE customers SET
				name = '$name',
				owner_name = '$owner_name',
				mobile = '$mobile',
				address = '$address',
				remark = '$remark',
				updated_by = '$updated_by',
				updated_at = '$date'
				WHERE id = '$id'";
				
			$result = $this->con()->query($query);
	
				
			if($result){
				$res = ['success'=>true, 'message'=>'Supplier Update Successfully'];
				return $res;
			}
			$res = ['success'=>false, 'Error Inserting Data !'];
			return $res;
		}	
}
		public function delete_supplier($data){

			$id= $this->con()->real_escape_string($data->id);
			$created_by= $this->con()->real_escape_string($data->created_by);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
				
			

					$query = "UPDATE suppliers SET
						updated_by = $created_by,
						deleted_at = '$date'
						WHERE id = '$id'";

					$result = $this->con()->query($query);
			
						
					if($result){
						$res = ['success'=>true, 'message'=>'Supplier Delete Successfully'];
						return $res;
					}
					$res = ['success'=>false, 'Error Inserting Data !'];
					return $res;
				
		}
	
	
	
}
?>