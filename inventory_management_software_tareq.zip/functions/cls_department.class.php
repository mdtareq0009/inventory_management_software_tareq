<?php
class cls_department{
	public function con(){
		$dbClass = new dbClass();
		return $dbClass->connection();
	}
	
	
	public function get_company(){
		$result = $this->con()->query("select * from company_profiles where status = '1'")[0];
		return $result;
	}
	
	
	
}
?>