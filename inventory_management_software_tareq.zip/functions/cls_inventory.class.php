<?php
class cls_inventory{
	public function con(){
		$dbClass = new dbClass();
		return $dbClass->connection();
	}
	
	
	public function get_purchase_code(){
		
		$productCode = "PUR00001";
        
        $lastProduct = $this->con()->query("SELECT * from purchases");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'PUR' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}
	public function get_sale_code(){
		
		$productCode = "Sale00001";
        
        $lastProduct = $this->con()->query("SELECT * from sales");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'Sale' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}

	public function get_purchase_return_code(){
		
		$productCode = "PR00001";
        
        $lastProduct = $this->con()->query("SELECT * from purchase_returns");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'PR' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}

	public function get_sale_return_code(){
		
		$productCode = "SR00001";
        
        $lastProduct = $this->con()->query("SELECT * from sale_returns");
        if(mysqli_num_rows($lastProduct) != 0){
            $newProductId = mysqli_num_rows($lastProduct) + 1;
            $zeros = array('0', '00', '000', '0000');
            $productCode = 'SR' . (strlen($newProductId) > count($zeros) ? $newProductId : $zeros[count($zeros) - strlen($newProductId)] . $newProductId);
        }

        return $productCode;
	}

	public function productStock($productId) {
		$productId = $this->con()->real_escape_string($productId);
        $stockQuery =$this->con()->query("select * from stocks where product_id = '$productId'");
        $stockCount = $stockQuery;
        $stock = 0;
        if(mysqli_num_rows($stockCount) != 0){
            $stockRow = $stockCount->fetch_assoc();
            $stock = ($stockRow['purchase_quantity'] + $stockRow['purchase_return_quantity']) 
                    - ($stockRow['sale_quantity'] + $stockRow['sale_return_quantity']);
        }

        return $stock;
    }
	public function totalStock($searchTypes,$productId=null,$categoryId=null,$data) {
		
        $clauses = "";
        if($searchTypes == 'category'){
            if($categoryId != null){
                $clauses .= " and p.category_id  = '$categoryId'";
            }
        }
        if($searchTypes == 'product'){
            if($productId != null){
                $clauses .= " and p.id = '$productId'";
            }
        }
        $stock =  $this->con()->query("
   
        SELECT
            p.*,
            pc.name as category_name,
            u.name as unit_name,
            (SELECT ifnull(sum(pd.quantity), 0) 
                from purchase_details pd 
                left join purchases pr on pr.id = pd.purchase_id
                where pd.product_id = p.id
                and pd.deleted_at is null
                " . (isset($date) && $date != null ? " and pr.order_date <= '$date'" : "") . "
            ) as purchased_quantity,
    
            (SELECT ifnull(sum(prd.quantity), 0) 
                from purchase_return_details prd 
                left join purchase_returns pr on pr.id = prd.purchase_return_id 
                where prd.product_id = p.id
                and prd.deleted_at is null
                " . (isset($date) && $date != null ? " and pr.return_date <= '$date'" : "") . "
            ) as purchased_return_quantity,
                    
            (SELECT ifnull(sum(sd.quantity), 0) 
                from sale_details sd
                left join sales s on s.id = sd.sale_id
                where sd.product_id = p.id
                and sd.deleted_at is null
                " . (isset($date) && $date != null ? " and s.order_date <= '$date'" : "") . "
            ) as sold_quantity,
    
            (SELECT ifnull(sum(isrud.quantity), 0) 
                from sale_return_details isrud
                left join sale_returns sr on sr.id = isrud.sale_return_id
                where isrud.product_id = p.id
                and isrud.deleted_at is null
                " . (isset($date) && $date != null ? " and sr.return_date <= '$date'" : "") . "
            ) as sale_return_quantity,
    
            (SELECT (purchased_quantity + sale_return_quantity) - (sold_quantity  + purchased_return_quantity)) as current_quantity,
            (SELECT p.purchase_price * current_quantity) as stock_value
        from products p
        left join categories pc on pc.id = p.category_id
        left join units u on u.id = p.unit_id
        where p.deleted_at is null
        $clauses
    ")->fetch_all(MYSQLI_ASSOC);
        return $stock;
    }
	public function currentStock() {

        $stock = $this->con()->query("SELECT * from(
            SELECT
                ci.*,
                (select (ci.purchase_quantity + ci.sale_return_quantity ) - (ci.sale_quantity + ci.purchase_return_quantity)) as current_quantity,
                p.name as product_name,
                p.product_code as product_code,
                pc.name as category_name,
                u.name as unit_name
            from stocks ci
            left join products p on p.id = ci.product_id
            left join categories pc on pc.id = p.category_id
            left join units u on u.id = p.unit_id
            where p.deleted_at is null
        ) as tbl
        where 1 = 1
        order by product_id asc
    ")->fetch_all(MYSQLI_ASSOC);


        return $stock;
    }

	public function store_purhcase($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{
          
            $invoice = $this->con()->real_escape_string($data->invoice_number);
            $invoiceCount = $this->con()->query("select * from purchases where invoice_number = '$invoice'");
            if(mysqli_num_rows($invoiceCount) != 0){
				$invoice = $this->get_purchase_code();
            }
			
			$order_date = $this->con()->real_escape_string($data->order_date);
			$supplier_id = $this->con()->real_escape_string($data->supplier_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
			$sql = "INSERT INTO purchases (invoice_number , order_date, supplier_id, total, remark, created_by,created_at)
			VALUES ('$invoice', '$order_date', '$supplier_id', '$total', '$note', '$created_by', '$date')";
			
			if ($this->con()->query($sql) === TRUE) {
				$result = $this->con()->query("SELECT * FROM purchases WHERE invoice_number = '$invoice'");
				$purchase = $result->fetch_assoc();
				$purchaseId = $purchase['id']; 
			} else {
				echo "Error: " . $sql . "<br>" . $this->con()->error;
			}

         
            foreach($cart as $key => $product){
				$pdate =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
				$purchase_id   = $purchaseId;
				$product_id    = $this->con()->real_escape_string($product->productId);
				$quantity      = $this->con()->real_escape_string($product->quantity);
				$purchase_rate = $this->con()->real_escape_string($product->purchase_price);
				$total_amount  = $this->con()->real_escape_string($product->total);
				$created_by    = $created_by;

				// Construct SQL query
				$sql = "INSERT INTO purchase_details (purchase_id, product_id, quantity, purchase_rate, total_amount, created_by, created_at) 
						VALUES ('$purchase_id', '$product_id', '$quantity', '$purchase_rate', '$total_amount', '$created_by', '$pdate')";

				if ($this->con()->query($sql) !== TRUE) {
					echo "Error: " . $sql . "<br>" . $this->con()->error;
    			}

              
                $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
				
                if(mysqli_num_rows($inventoryCount) == 0){
					$sql = "INSERT INTO stocks ( product_id, purchase_quantity) 
						VALUES ('$product_id', '$quantity')";

						$this->con()->query($sql);
                } else {
                    $this->con()->query("
                        update stocks 
                        set purchase_quantity = purchase_quantity + '$quantity' 
                        where product_id = '$product_id'
                    ");
                }

               
            }

            $res=['success'=>true, 'message'=>'Purchase Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

        return $res;
	}
	public function purchase_record($purchaseId=null,$sid=null,$fromdata,$todate,$withdetails){
		
        $purchaseId = $this->con()->real_escape_string($purchaseId);
        $supplierId = $this->con()->real_escape_string($sid);
        $dateFrom = $this->con()->real_escape_string($fromdata);
        $dateTo = $this->con()->real_escape_string($todate);
        $with_details = $this->con()->real_escape_string($withdetails);

	
        $clauses = "";
        if(isset($dateFrom) && $dateFrom != '' && isset($dateTo) && $dateTo != ''){
            $clauses .= " and pm.order_date between '$dateFrom' and '$dateTo'";
        }
        
        if(isset($supplierId) && $supplierId != ''){
            $clauses .= " and pm.supplier_id = '$supplierId'";
        }


		
		$purchases = $this->con()->query("SELECT
		concat(pm.invoice_number, ' - ', s.name) as display_name,
		pm.*,
		s.name as supplier_name,
		s.mobile as supplier_mobile,
		s.supplier_code as code,
		s.address as supplier_address
		from purchases pm
		join suppliers s on s.id = pm.supplier_id
		where pm.status = 'a'
		and pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);


if ($with_details == true) {
    $getPurchaseDetails = function($purchase) {
       
        if (!isset($purchase['id'])) {
            return $purchase;
        }

        $purchaseId = $this->con()->real_escape_string($purchase['id']);

        $detailsQuery = "
            SELECT
                pd.*,
                p.name AS product_name,
                p.product_code,
                p.category_id,
                p.sale_price,
                pc.name AS category_name,
                u.name AS unit_name
            FROM purchase_details pd
            JOIN products p ON p.id = pd.product_id
            LEFT JOIN categories pc ON pc.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE pd.purchase_id = '$purchaseId'
			and pd.deleted_at IS NULL
        ";

        $detailsResult = $this->con()->query($detailsQuery);

        if ($detailsResult === false) {
            die('Detail query failed: ' . htmlspecialchars($this->con()->error));
        }

        $purchase['purchase_details'] = $detailsResult->fetch_all(MYSQLI_ASSOC);
		
        return $purchase;
    };

    $purchases = array_map($getPurchaseDetails, $purchases);
}
      
       
        return $purchases;
    }

   
	public function update_purhcase($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{

        
            $id = $this->con()->real_escape_string($data->id);
            $order_date = $this->con()->real_escape_string($data->order_date);
			$supplier_id = $this->con()->real_escape_string($data->supplier_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
           
            $query = "UPDATE purchases SET
            order_date = '$order_date',
            supplier_id = '$supplier_id',
            total = '$total',
            remark = '$note',
            updated_by = '$created_by',
            updated_at = '$date'
            WHERE id = '$id'";
           
        $result = $this->con()->query($query);
       
        $oldPurchaseDetails =  $this->con()->query("select * from purchase_details where purchase_id='$id'")->fetch_all(MYSQLI_ASSOC);
        
        $delete_details = $this->con()->query("delete from purchase_details where purchase_id='$id' ");
        

        foreach ($oldPurchaseDetails as $key => $product) {

            $this->con()->query("
                    update stocks 
                    set purchase_quantity = purchase_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']."
                ");

        }
          
        foreach($cart as $key => $product){
            $pdate =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
            $purchase_id   = $id;
            $product_id    = $this->con()->real_escape_string($product->productId);
            $quantity      = $this->con()->real_escape_string($product->quantity);
            $purchase_rate = $this->con()->real_escape_string($product->purchase_price);
            $total_amount  = $this->con()->real_escape_string($product->total);
            $created_by    = $created_by;

            // Construct SQL query
            $sql = "INSERT INTO purchase_details (purchase_id, product_id, quantity, purchase_rate, total_amount, created_by, created_at) 
                    VALUES ('$purchase_id', '$product_id', '$quantity', '$purchase_rate', '$total_amount', '$created_by', '$pdate')";

            if ($this->con()->query($sql) !== TRUE) {
                echo "Error: " . $sql . "<br>" . $this->con()->error;
            }

          
            $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
            
            if(mysqli_num_rows($inventoryCount) == 0){
                $sql = "INSERT INTO stocks ( product_id, purchase_quantity) 
                    VALUES ('$product_id', '$quantity')";

                    $this->con()->query($sql);
            } else {
                $this->con()->query("
                    update stocks 
                    set purchase_quantity = purchase_quantity + '$quantity' 
                    where product_id = '$product_id'
                ");
            }           
        }


            $res=['success'=>true, 'message'=>'Purchase Update Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

		return $res;
    }



	public function delete_purchase($data){

		
		
		$res = ['success'=>false, 'message'=>''];
        try{
			$id= $this->con()->real_escape_string($data);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));


            /*Get Purchase Details Data*/
            $purchaseDetails = $this->con()->query("select product_id,quantity,total_amount from purchase_details where purchase_id ='$id'")->fetch_all(MYSQLI_ASSOC);

            foreach($purchaseDetails as $detail) {
                $stock = $this->productStock($detail['product_id']);
				
                if($detail['quantity'] > $stock) {
                    $res = ['success'=>false, 'message'=>'Product out of stock, Purchase can not be deleted'];   
                    echo json_encode($res);
                    exit;
                }
            }

		

            foreach($purchaseDetails as $product){
              
				$this->con()->query("
                    update stocks 
                    set purchase_quantity = purchase_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']." 
                ");

            }
			$this->con()->query("
			update purchases 
			set deleted_at = '$date' 
			where id = '$id'
			");
			$this->con()->query("
			update purchase_details 
			set deleted_at = '$date' 
			where purchase_id = '$id'
			");
            
            $res = ['success'=>true, 'message'=>'Successfully deleted'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }
				return $res;
			
	}
    public function store_purhcase_return($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{
          
            $invoice = $this->con()->real_escape_string($data->invoice_number);
            $invoiceCount = $this->con()->query("select * from purchase_returns where invoice_number = '$invoice'");
            if(mysqli_num_rows($invoiceCount) != 0){
				$invoice = $this->get_purchase_code();
            }
			
			$return_date = $this->con()->real_escape_string($data->return_date);
			$supplier_id = $this->con()->real_escape_string($data->supplier_id);
			$total_amount = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
			$sql = "INSERT INTO purchase_returns (invoice_number , return_date, supplier_id, total_amount, remark, created_by,created_at)
			VALUES ('$invoice', '$return_date', '$supplier_id', '$total_amount', '$note', '$created_by', '$date')";
			
			if ($this->con()->query($sql) === TRUE) {
				$result = $this->con()->query("SELECT * FROM purchase_returns WHERE invoice_number = '$invoice'");
				$purchasereturn = $result->fetch_assoc();
				$purchaseReturnId = $purchasereturn['id']; 
			} else {
				echo "Error: " . $sql . "<br>" . $this->con()->error;
			}

         
            foreach($cart as $key => $product){
				$pdate              = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
				$purchase_return_id = $purchaseReturnId;
				$product_id         = $this->con()->real_escape_string($product->productId);
				$quantity           = $this->con()->real_escape_string($product->quantity);
				$return_rate        = $this->con()->real_escape_string($product->return_rate);
				$total_amount       = $this->con()->real_escape_string($product->total);
				$created_by         = $created_by;

				// Construct SQL query
				$sql = "INSERT INTO purchase_return_details (purchase_return_id, product_id, quantity, return_rate, total_amount, created_by, created_at) 
						VALUES ('$purchase_return_id', '$product_id', '$quantity', '$return_rate', '$total_amount', '$created_by', '$pdate')";

				if ($this->con()->query($sql) !== TRUE) {
					echo "Error: " . $sql . "<br>" . $this->con()->error;
    			}

              
                $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
				
                if(mysqli_num_rows($inventoryCount) != 0){
				
                    $this->con()->query("
                        update stocks 
                        set purchase_return_quantity = purchase_return_quantity + '$quantity' 
                        where product_id = '$product_id'
                    ");
                }

               
            }

            $res=['success'=>true, 'message'=>'Purchase Return Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

        return $res;
	}
	public function purchase_return_record($purchaseId=null,$sid=null,$fromdata,$todate,$withdetails){
		
        $purchaseId = $this->con()->real_escape_string($purchaseId);
        $supplierId = $this->con()->real_escape_string($sid);
        $dateFrom = $this->con()->real_escape_string($fromdata);
        $dateTo = $this->con()->real_escape_string($todate);
        $with_details = $this->con()->real_escape_string($withdetails);

	
        $clauses = "";
        if(isset($dateFrom) && $dateFrom != '' && isset($dateTo) && $dateTo != ''){
            $clauses .= " and pm.return_date between '$dateFrom' and '$dateTo'";
        }
        
        if(isset($supplierId) && $supplierId != ''){
            $clauses .= " and pm.supplier_id = '$supplierId'";
        }


		
		$purchasereturn = $this->con()->query("SELECT
		concat(pm.invoice_number, ' - ', s.name) as display_name,
		pm.*,
		s.name as supplier_name,
		s.mobile as supplier_mobile,
		s.supplier_code as code,
		s.address as supplier_address
		from purchase_returns pm
		join suppliers s on s.id = pm.supplier_id
		where pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);


if ($with_details == true) {
    $getPurchaseReturnDetails = function($purchasereturn) {
       
        if (!isset($purchasereturn['id'])) {
            return $purchasereturn;
        }

        $purchaseId = $this->con()->real_escape_string($purchasereturn['id']);

        $detailsQuery = "
            SELECT
                pd.*,
                p.name AS product_name,
                p.product_code,
                p.category_id,
                p.sale_price,
                pc.name AS category_name,
                u.name AS unit_name
            FROM purchase_return_details pd
            JOIN products p ON p.id = pd.product_id
            LEFT JOIN categories pc ON pc.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE pd.purchase_return_id = '$purchaseId'
			and pd.deleted_at IS NULL
        ";

        $detailsResult = $this->con()->query($detailsQuery);
     
        if ($detailsResult === false) {
            die('Detail query failed: ' . htmlspecialchars($this->con()->error));
        }

        $purchasereturn['purchase_return_details'] = $detailsResult->fetch_all(MYSQLI_ASSOC);
		
        return $purchasereturn;
    };

    $purchasereturn = array_map($getPurchaseReturnDetails, $purchasereturn);
}
      
       
        return $purchasereturn;
    }

   
	public function update_purhcase_return($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{

        
            $id = $this->con()->real_escape_string($data->id);
            $return_date = $this->con()->real_escape_string($data->return_date);
			$supplier_id = $this->con()->real_escape_string($data->supplier_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));

            $query = "UPDATE purchase_returns SET
            return_date = '$return_date',
            supplier_id = '$supplier_id',
            total_amount = '$total',
            remark = '$note',
            updated_by = '$created_by',
            updated_at = '$date'
            WHERE id = '$id'";
           
        $result = $this->con()->query($query);
       
        $oldPurchaseReturnDetails =  $this->con()->query("select * from purchase_return_details where purchase_return_id='$id'")->fetch_all(MYSQLI_ASSOC);
        
        $delete_details = $this->con()->query("delete from purchase_return_details where purchase_return_id='$id' ");
        

        foreach ($oldPurchaseReturnDetails as $key => $product) {

            $this->con()->query("
                    update stocks 
                    set purchase_return_quantity = purchase_return_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']."
                ");

        }
          
        foreach($cart as $key => $product){
            $pdate              = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
            $purchase_return_id = $id;
            $product_id         = $this->con()->real_escape_string($product->productId);
            $quantity           = $this->con()->real_escape_string($product->quantity);
            $return_rate        = $this->con()->real_escape_string($product->return_rate);
            $total_amount       = $this->con()->real_escape_string($product->total);
            $created_by         = $created_by;

            // Construct SQL query
            $sql = "INSERT INTO purchase_return_details (purchase_return_id, product_id, quantity, return_rate, total_amount, created_by, created_at) 
                    VALUES ('$purchase_return_id', '$product_id', '$quantity', '$return_rate', '$total_amount', '$created_by', '$pdate')";

            if ($this->con()->query($sql) !== TRUE) {
                echo "Error: " . $sql . "<br>" . $this->con()->error;
            }

          
            $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
            
            if(mysqli_num_rows($inventoryCount) != 0){
            
                $this->con()->query("
                    update stocks 
                    set purchase_return_quantity = purchase_return_quantity + '$quantity' 
                    where product_id = '$product_id'
                ");
            }

           
        }


            $res=['success'=>true, 'message'=>'Purchase Return Update Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

		return $res;
    }


	public function delete_purchase_return($data){

		
		
		$res = ['success'=>false, 'message'=>''];
        try{
			$id= $this->con()->real_escape_string($data);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));


            /*Get Purchase Details Data*/
            $purchaseDetails = $this->con()->query("select product_id,quantity from purchase_return_details where purchase_return_id ='$id'")->fetch_all(MYSQLI_ASSOC);

            foreach($purchaseDetails as $detail) {
                $stock = $this->productStock($detail['product_id']);
				
                if($detail['quantity'] > $stock) {
                    $res = ['success'=>false, 'message'=>'Product out of stock, Purchase can not be deleted'];   
                    echo json_encode($res);
                    exit;
                }
            }

		

            foreach($purchaseDetails as $product){
              
				$this->con()->query("
                    update stocks 
                    set purchase_return_quantity = purchase_return_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']." 
                ");

            }
			$this->con()->query("
			update purchase_returns 
			set deleted_at = '$date' 
			where id = '$id'
			");
			$this->con()->query("
			update purchase_return_details 
			set deleted_at = '$date' 
			where purchase_return_id = '$id'
			");
            
            $res = ['success'=>true, 'message'=>'Successfully deleted'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }
				return $res;
			
	}

	public function store_sale($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{
          
            $invoice = $this->con()->real_escape_string($data->invoice_number);
            $invoiceCount = $this->con()->query("select * from sales where invoice_number = '$invoice'");
            if(mysqli_num_rows($invoiceCount) != 0){
				$invoice = $this->get_sale_code();
            }
			
			$order_date = $this->con()->real_escape_string($data->order_date);
			$customer_id = $this->con()->real_escape_string($data->customer_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
			$sql = "INSERT INTO sales (invoice_number , order_date, customer_id, total, remark, created_by,created_at)
			VALUES ('$invoice', '$order_date', '$customer_id', '$total', '$note', '$created_by', '$date')";
			
			if ($this->con()->query($sql) === TRUE) {
				$result = $this->con()->query("SELECT * FROM sales WHERE invoice_number = '$invoice'");
				$sale = $result->fetch_assoc();
				$saleId = $sale['id']; 
			} else {
				echo "Error: " . $sql . "<br>" . $this->con()->error;
			}

            foreach($cart as $key => $product){

				$pdate         = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
				$sale_id       = $saleId;
				$product_id    = $this->con()->real_escape_string($product->productId);
				$quantity      = $this->con()->real_escape_string($product->quantity);
				$purchase_rate = $this->con()->real_escape_string($product->purchase_price);
				$sale_rate     = $this->con()->real_escape_string($product->sale_rate);
				$total_amount  = $this->con()->real_escape_string($product->total);
				$created_by    = $created_by;

				$sql = "INSERT INTO sale_details(sale_id, product_id, quantity, purchase_rate, sale_rate , total_amount, created_by, created_at) 
						VALUES('$sale_id', '$product_id', '$quantity', '$purchase_rate', '$sale_rate' , '$total_amount', '$created_by', '$pdate')";
                
				if ($this->con()->query($sql) !== TRUE) {
					echo "Error: " . $sql . "<br>" . $this->con()->error;
    			}

              
                $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
				
                if(mysqli_num_rows($inventoryCount) != 0){
					$this->con()->query("
                        update stocks 
                        set sale_quantity = sale_quantity + '$quantity' 
                        where product_id = '$product_id'
                    ");
                } 

               
            }

            $res=['success'=>true, 'message'=>'Sale Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

        return $res;
	}
	public function sale_record($saleId=null,$customer_id=null,$fromdata,$todate,$withdetails){
		
        $saleId       = $this->con()->real_escape_string($saleId);
        $customer_id  = $this->con()->real_escape_string($customer_id);
        $dateFrom     = $this->con()->real_escape_string($fromdata);
        $dateTo       = $this->con()->real_escape_string($todate);
        $with_details = $this->con()->real_escape_string($withdetails);

	
        $clauses = "";
        if(isset($dateFrom) && $dateFrom != '' && isset($dateTo) && $dateTo != ''){
            $clauses .= " and pm.order_date between '$dateFrom' and '$dateTo'";
        }
        
        if(isset($customer_id) && $customer_id != ''){
            $clauses .= " and pm.supplier_id = '$customer_id'";
        }


		
		$sale = $this->con()->query("SELECT
		concat(pm.invoice_number, ' - ', c.name) as display_name,
		pm.*,
		c.name as customer_name,
		c.mobile as customer_mobile,
		c.customer_code as code,
		c.address as customer_address
		from sales pm
		join customers c on c.id = pm.customer_id
		where pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);


if ($with_details == true) {
    $getSaleDetails = function($sale) {
       
        if (!isset($sale['id'])) {
            return $sale;
        }

        $saleId = $this->con()->real_escape_string($sale['id']);

        $detailsQuery = "
            SELECT
                pd.*,
                p.name AS product_name,
                p.product_code,
                p.category_id,
                p.sale_price,
                pc.name AS category_name,
                u.name AS unit_name
            FROM sale_details pd
            JOIN products p ON p.id = pd.product_id
            LEFT JOIN categories pc ON pc.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE pd.sale_id = '$saleId'
			and pd.deleted_at IS NULL
        ";

        $detailsResult = $this->con()->query($detailsQuery);

        if ($detailsResult === false) {
            die('Detail query failed: ' . htmlspecialchars($this->con()->error));
        }

        $sale['sale_details'] = $detailsResult->fetch_all(MYSQLI_ASSOC);
		
        return $sale;
    };

    $sale = array_map($getSaleDetails, $sale);
}
      
       
        return $sale;
    }

   
	public function update_sale($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{

        
            $id = $this->con()->real_escape_string($data->id);
            $order_date = $this->con()->real_escape_string($data->order_date);
			$customer_id = $this->con()->real_escape_string($data->customer_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
           
            $query = "UPDATE sales SET
            order_date = '$order_date',
            customer_id = '$customer_id',
            total = '$total',
            remark = '$note',
            updated_by = '$created_by',
            updated_at = '$date'
            WHERE id = '$id'";
           
        $result = $this->con()->query($query);
       
        $oldPurchaseDetails =  $this->con()->query("select * from sale_details where sale_id='$id'")->fetch_all(MYSQLI_ASSOC);
        
        $delete_details = $this->con()->query("delete from sale_details where sale_id='$id' ");
        

        foreach ($oldPurchaseDetails as $key => $product) {

            $this->con()->query("
                    update stocks 
                    set sale_quantity = sale_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']."
                ");

        }
          
        foreach($cart as $key => $product){
            $pdate         = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
            $sale_id       = $id;
            $product_id    = $this->con()->real_escape_string($product->productId);
            $quantity      = $this->con()->real_escape_string($product->quantity);
            $purchase_rate = $this->con()->real_escape_string($product->purchase_price);
            $sale_rate     = $this->con()->real_escape_string($product->sale_rate);
            $total_amount  = $this->con()->real_escape_string($product->total);
            $created_by    = $created_by;

            // Construct SQL query
            $sql = "INSERT INTO sale_details (sale_id, product_id, quantity, purchase_rate, sale_rate, total_amount, created_by, created_at) 
                    VALUES ('$sale_id', '$product_id', '$quantity', '$purchase_rate','$sale_rate','$total_amount', '$created_by', '$pdate')";

            if ($this->con()->query($sql) !== TRUE) {
                echo "Error: " . $sql . "<br>" . $this->con()->error;
            }

          
            $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
            
            if(mysqli_num_rows($inventoryCount) != 0){
                $this->con()->query("
                    update stocks 
                    set sale_quantity = sale_quantity + '$quantity' 
                    where product_id = '$product_id'
                ");
            }          
        }


            $res=['success'=>true, 'message'=>'Sale Update Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

		return $res;
    }



	public function delete_sale($data){

		$res = ['success'=>false, 'message'=>''];
        try{
			$id= $this->con()->real_escape_string($data);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));


            /*Get Purchase Details Data*/
            $saleDetails = $this->con()->query("select product_id,quantity,total_amount from sale_details where sale_id ='$id'")->fetch_all(MYSQLI_ASSOC);

            foreach($saleDetails as $detail) {
                $stock = $this->productStock($detail['product_id']);
				
                if($detail['quantity'] > $stock) {
                    $res = ['success'=>false, 'message'=>'Product out of stock, Purchase can not be deleted'];   
                    echo json_encode($res);
                    exit;
                }
            }

		
            foreach($saleDetails as $product){
              
				$this->con()->query("
                    update stocks 
                    set sale_quantity = sale_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']." 
                ");

            }
			$this->con()->query("
			update sales 
			set deleted_at = '$date' 
			where id = '$id'
			");
			$this->con()->query("
			update sale_details 
			set deleted_at = '$date' 
			where sale_id = '$id'
			");
            
            $res = ['success'=>true, 'message'=>'Successfully deleted'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }
				return $res;
			
	}
	public function store_sale_return($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{


            $invoice = $this->con()->real_escape_string($data->invoice_number);
            $invoiceCount = $this->con()->query("select * from sale_returns where invoice_number = '$invoice'");
            if(mysqli_num_rows($invoiceCount) != 0){
				$invoice = $this->get_sale_return_code();
            }
			
			$return_date = $this->con()->real_escape_string($data->return_date);
			$customer_id = $this->con()->real_escape_string($data->customer_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
			
			$sql = "INSERT INTO sale_returns (invoice_number , return_date, customer_id, total_amount, remark, created_by ,created_at)
			VALUES ('$invoice', '$return_date', '$customer_id', '$total', '$note', '$created_by', '$date')";
			
           
			
            if ($this->con()->query($sql) === TRUE) {
				$result = $this->con()->query("SELECT * FROM sale_returns WHERE invoice_number = '$invoice'");
				$salereturn = $result->fetch_assoc();
				$salereturnId = $salereturn['id']; 
			} else {
				echo "Error: " . $sql . "<br>" . $this->con()->error;
			}

            foreach($cart as $key => $product){

				$pdate          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
				$sale_return_id = $salereturnId;
				$product_id     = $this->con()->real_escape_string($product->productId);
				$quantity       = $this->con()->real_escape_string($product->quantity);
				$return_rate    = $this->con()->real_escape_string($product->return_rate);
				$total_amount   = $this->con()->real_escape_string($product->total);
				$created_by     = $created_by;

				$sql = "INSERT INTO sale_return_details(sale_return_id, product_id, quantity, return_rate, total_amount, created_by, created_at) 
						VALUES('$sale_return_id', '$product_id', '$quantity', '$return_rate',  '$total_amount', '$created_by', '$pdate')";
                
				if ($this->con()->query($sql) !== TRUE) {
					echo "Error: " . $sql . "<br>" . $this->con()->error;
    			}

              
                $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
				
                if(mysqli_num_rows($inventoryCount) != 0){
					$this->con()->query("
                        update stocks 
                        set sale_return_quantity = sale_return_quantity + '$quantity' 
                        where product_id = '$product_id'
                    ");
                } 

               
            }

            $res=['success'=>true, 'message'=>'Sale Return Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

        return $res;
	}
	public function sale_return_record($salereturnId=null,$customer_id=null,$fromdata,$todate,$withdetails){
		
        $salereturnId       = $this->con()->real_escape_string($salereturnId);
        $customer_id  = $this->con()->real_escape_string($customer_id);
        $dateFrom     = $this->con()->real_escape_string($fromdata);
        $dateTo       = $this->con()->real_escape_string($todate);
        $with_details = $this->con()->real_escape_string($withdetails);

	
        $clauses = "";
        if(isset($dateFrom) && $dateFrom != '' && isset($dateTo) && $dateTo != ''){
            $clauses .= " and pm.return_date between '$dateFrom' and '$dateTo'";
        }
        
        if(isset($customer_id) && $customer_id != ''){
            $clauses .= " and pm.customer_id = '$customer_id'";
        }


		
		$salereturn = $this->con()->query("SELECT
		concat(pm.invoice_number, ' - ', c.name) as display_name,
		pm.*,
		c.name as customer_name,
		c.mobile as customer_mobile,
		c.customer_code as code,
		c.address as customer_address
		from sale_returns pm
		join customers c on c.id = pm.customer_id
		where pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);


if ($with_details == true) {
    $getSaleReturnDetails = function($salereturn) {
       
        if (!isset($salereturn['id'])) {
            return $salereturn;
        }

        $salereturnId = $this->con()->real_escape_string($salereturn['id']);
        
        
        $detailsQuery = "
            SELECT
                pd.*,
                p.name AS product_name,
                p.product_code,
                p.category_id,
                pc.name AS category_name,
                u.name AS unit_name
            FROM sale_return_details pd
            JOIN products p ON p.id = pd.product_id
            LEFT JOIN categories pc ON pc.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE pd.sale_return_id = '$salereturnId'
			and pd.deleted_at IS NULL
        ";

        $detailsResult = $this->con()->query($detailsQuery);

      
        if ($detailsResult === false) {
            die('Detail query failed: ' . htmlspecialchars($this->con()->error));
        }

        $salereturn['sale_return_details'] = $detailsResult->fetch_all(MYSQLI_ASSOC);
		
        return $salereturn;
    };

    $salereturn = array_map($getSaleReturnDetails, $salereturn);
}
      
       
        return $salereturn;
    }

   
	public function update_sale_return($data,$cart)
    {
        $res = ['success'=>false, 'message'=>''];
        try{

        
            $id = $this->con()->real_escape_string($data->id);
            $return_date = $this->con()->real_escape_string($data->return_date);
			$customer_id = $this->con()->real_escape_string($data->customer_id);
			$total = $this->con()->real_escape_string($data->total);
			$note = $this->con()->real_escape_string($data->note);
			$created_by = $this->con()->real_escape_string($data->created_by);
			$date =  $this->con()->real_escape_string(date('Y-m-d H:i:s'));
           
            $query = "UPDATE sale_returns SET
            return_date = '$return_date',
            customer_id = '$customer_id',
            total = '$total',
            remark = '$note',
            updated_by = '$created_by',
            updated_at = '$date'
            WHERE id = '$id'";
           
        $result = $this->con()->query($query);
       
        $oldSaleReturnDetails =  $this->con()->query("select * from sale_return_details where sale_return_id='$id'")->fetch_all(MYSQLI_ASSOC);
        
        $delete_details = $this->con()->query("delete from sale_return_details where sale_return_id='$id' ");
        

        foreach ($oldSaleReturnDetails as $key => $product) {

            $this->con()->query("
                    update stocks 
                    set sale_return_quantity = sale_return_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']."
                ");

        }
          
        foreach($cart as $key => $product){

            $pdate          = $this->con()->real_escape_string(date('Y-m-d H:i:s'));
            $sale_return_id = $id;
            $product_id     = $this->con()->real_escape_string($product->productId);
            $quantity       = $this->con()->real_escape_string($product->quantity);
            $return_rate    = $this->con()->real_escape_string($product->return_rate);
            $total_amount   = $this->con()->real_escape_string($product->total);
            $created_by     = $created_by;

            $sql = "INSERT INTO sale_return_details(sale_return_id, product_id, quantity, return_rate, total_amount, created_by, created_at) 
                    VALUES('$sale_return_id', '$product_id', '$quantity', '$return_rate',  '$total_amount', '$created_by', '$pdate')";
            
            if ($this->con()->query($sql) !== TRUE) {
                echo "Error: " . $sql . "<br>" . $this->con()->error;
            }

          
            $inventoryCount = $this->con()->query("select * from stocks where product_id  = '$product->productId'");
            
            if(mysqli_num_rows($inventoryCount) != 0){
                $this->con()->query("
                    update stocks 
                    set sale_return_quantity = sale_return_quantity + '$quantity' 
                    where product_id = '$product_id'
                ");
            } 

           
        }


            $res=['success'=>true, 'message'=>'Sale Return Update Success'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }

		return $res;
    }



	public function delete_sale_return($data){

		$res = ['success'=>false, 'message'=>''];
        try{
			$id= $this->con()->real_escape_string($data);
			$date= $this->con()->real_escape_string(date('Y-m-d H:i:s'));


            /*Get Purchase Details Data*/
            $saleReturnDetails = $this->con()->query("select product_id,quantity from sale_return_details where sale_return_id ='$id'")->fetch_all(MYSQLI_ASSOC);

		
            foreach($saleReturnDetails as $product){
              
				$this->con()->query("
                    update stocks 
                    set sale_return_quantity = sale_return_quantity - ".$product['quantity']." 
                    where product_id = ".$product['product_id']." 
                ");

            }
			$this->con()->query("
			update sale_returns 
			set deleted_at = '$date' 
			where id = '$id'
			");
			$this->con()->query("
			update sale_return_details 
			set deleted_at = '$date' 
			where sale_return_id = '$id'
			");
            
            $res = ['success'=>true, 'message'=>'Successfully deleted'];
        } catch (Exception $ex){
            $res = ['success'=>false, 'message'=>$ex->getMessage()];
        }
				return $res;
			
	}




	
	
	
}
?>