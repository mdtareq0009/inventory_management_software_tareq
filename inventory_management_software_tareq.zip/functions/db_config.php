<?php
	class dbClass{
		public function connection(){
			$db = new mysqli("localhost", "root", '', "managment_db");
				// $db = new mysqli("localhost", "bigtech_dairy", "!2^hh4={kWN*","bigtech_dairy");
			return $db;
		}
	}
?>