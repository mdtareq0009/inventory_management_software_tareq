
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>General user Registration</title>

    <meta name="description" content="Static &amp; Dynamic Tables" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

    <link rel="stylesheet" href="assets/general_login/css/app.css">
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.png">
</head>
<body class="skin-2">
<div class="main-container ace-save-state" id="main-container">
        <div class="main-content">
            <div class="main-content-inner">
                <div class="page-content" id="app">
<div class="container" id="general_user">
	<div class="contant">
		<div class="login">
			<div class="right-cont">
				<div class="login-form">	
			<form @submit.prevent="saveUser">
            <div class="row" style="width:100%; margin:0px auto; margin-top: 150px;">
                <div class="col-md-6 col-md-offset-3" style="background: beige;border-radius: 25px;padding-bottom: 15px;">
                    <h5 class="text-center green">New User Registration</h5>
                    <div class="form-group clearfix">
                        <label class="control-label col-md-4">Name:</label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" v-model="user.name" required>
                        </div>
                    </div>


                    <div class="form-group clearfix">
                        <label class="control-label col-md-4">Email:</label>
                        <div class="col-md-7">
                            <input type="email" class="form-control" v-model="user.username" required>
                        </div>
                    </div>
                 
                    <div class="form-group clearfix">
                        <label class="control-label col-md-4">Password:</label>
                        <div class="col-md-7">
                            <input type="password" v-model="user.password" class="form-control">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <label class="control-label col-md-4">Re-Password:</label>
                        <div class="col-md-7">
                            <input type="password" class="form-control" v-model="user.password_confirmation">
                            <span  v-if="user.password != '' && user.password_confirmation != ''">
                                <span v-if="user.password === user.password_confirmation" style="color: green;">Password Match!</span>
                                <span v-else style="color: red;">Password Not Match!</span>
                            </span>
                        </div>
                    </div>
                    
                    <div class="form-group clearfix">
                        <div class="col-md-7 col-md-offset-4">
                            <input type="submit" class="btn btn-success btn-sm" style="padding:2px;" value="Register">
                        </div>
                    </div>
                </div>	

            </div>
        </form>
					
				</div>
			</div>
	
			<div class="clr"></div>
		</div>
	</div>

</div>

</div>
            </div>
        </div>

    </div>
    
      

<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	new Vue({
		el: '#general_user',
    data () {
        return {
            user: {
                id                   : '',
                name                 : '',
                username             : '',
                role                 : 'General',
                password             : '',
                password_confirmation: '',
            },
        }
    },
  
    methods: {
        
      
       saveUser(){
          

            if(this.user.id == '' && this.user.password == ''){
                alert('password required!');
                return;
            }

            if(this.user.password != '' && this.user.password !== this.user.password_confirmation){
                alert('password not match!');
                return;
            }

            this.user.branch_id = 1;

            let url = 'post_url/reg_user_general';
            

            let fd = new FormData();
            fd.append('users', JSON.stringify(this.user));

            Swal.fire({
            title: '<strong>Are you sure!</strong>',
            html: '<strong>Want to Proccess this?</strong>',
            showDenyButton: true,
            confirmButtonText: `Ok`,
            denyButtonText: `Cancel`,
             }).then((result) => {
            if (result.isConfirmed) {
                axios.post(url, fd).then(async res=>{
                    let r = res.data;
                    
                    Swal.fire({
                        icon: 'success',
                        title: r.message,
                        showConfirmButton: false,
                        timer: 2000
                    })
                    await new Promise(r => setTimeout(r, 2000));
                    
                    window.location = 'https://localhost/inventroy_management';
                  
                    
                }).catch(error => {
                    let e = error.response.data;

                    if(e.hasOwnProperty('message')){
                        if(e.hasOwnProperty('errors')){
                            Object.entries(e.errors).forEach(([key, val])=>{
                                this.$toaster.error(val[0]);
                            })
                        }else{
                            this.$toaster.error(e.message);
                        }
                    }else{
                        this.$toaster.error(e);
                    }
                })
            }
        })
        },
        
    }
});
</script>

</body>
</html>