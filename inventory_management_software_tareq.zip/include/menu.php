
<style>
	.module_title {
		background-color: #00BE67 !important;
		text-align: center;
		font-size: 18px !important;
		font-weight: bold;
		font-style: italic;
		color: #fff !important;
	}

	.module_title span {
		font-size: 18px !important;
	}
</style>

<?php
// print_r($this->session->userdata()); die();
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];
$role =  $_SESSION['role'];
$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}

$access = isset($access) && is_array($access) ? $access : [];
$all_access_role = ['Admin', 'General'];

if ($module == 'dashboard' or $module == '') {
	?>
	<ul class="nav nav-list">
		<li class="active">
			<!-- module/dashboard -->
			<a href="/">
				<i class="menu-icon fa fa-tachometer"></i>
				<span class="menu-text"> Dashboard </span>
			</a>
			<b class="arrow"></b>
		</li>

		<li class="">
			<a href="inventory">
				<i class="menu-icon fa fa-usd"></i>
				<span class="menu-text"> Inventory </span>
			</a>
			<b class="arrow"></b>
		</li>


		<li class="">
			<a href="administration">
				<i class="menu-icon fa fa-cogs"></i>
				<span class="menu-text"> Administration </span>
			</a>
			<b class="arrow"></b>
		</li>
		
		<li class="">
            <a href="" id="logOut" class="logOut">
				<i class="menu-icon fa fa-bar-chart"></i>
				<span class="menu-text"> Logout </span>
			</a>
			<b class="arrow"></b>
		</li>
	</ul>
<?php } elseif ($module == 'Administration') { ?>
	<ul class="nav nav-list">
		<li class="active">
			<a href="dashboard">
				<i class="menu-icon fa fa-tachometer"></i>
				<span class="menu-text"> Dashboard </span>
			</a>
			<b class="arrow"></b>
		</li>
		<li>
			<a href="administration" class="module_title">
				<span>Administration</span>
			</a>
		</li>

		<?php if (array_search("product", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="product">
					<i class="menu-icon fa fa-product-hunt"></i>
					<span class="menu-text"> Product </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("product_list", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="product_list">
					<i class="menu-icon fa fa-list"></i>
					<span class="menu-text"> Product List</span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("category", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="category">
					<i class="menu-icon fa fa-product-hunt"></i>
					<span class="menu-text"> Category </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("unit", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="unit">
					<i class="menu-icon fa fa-product-hunt"></i>
					<span class="menu-text"> Unit </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("customer", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="customer">
					<i class="menu-icon fa fa-user"></i>
					<span class="menu-text"> Customer </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("supplier", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="supplier">
					<i class="menu-icon fa fa-user"></i>
					<span class="menu-text"> Supplier </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("register", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="register">
					<i class="menu-icon fa fa-users"></i>
					<span class="menu-text"> User Entry </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
	</ul><!-- /.nav-list -->

<?php } elseif ($module == 'inventory') { ?>
	<ul class="nav nav-list">

		<li class="active">
			<a href="dashboard">
				<i class="menu-icon fa fa-tachometer"></i>
				<span class="menu-text"> Dashboard </span>
			</a>

			<b class="arrow"></b>
		</li>
		<li>
			<a href="inventory" class="module_title">
				<span> Inventory Module </span>
			</a>
		</li>

		<?php if (array_search("purchase", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="purchase">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Purcahse Entry </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("sales", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="sales">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Sales Entry </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("purchase_return", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="purchase_return">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Purchase Return </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("sales_return", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="sales_return">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Sales Return Entry </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("purchase_record", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="purchase_record">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Purchase Record </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("purchase_return_record", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="purchase_return_record">
					<i class="menu-icon fa fa-list"></i>
					<span class="menu-text"> Pur. Return Record </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("sale_return_record", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="sale_return_record">
					<i class="menu-icon fa fa-list"></i>
					<span class="menu-text"> Sales Return Record </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("sale_record", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="sale_record">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Sales Record </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>
		<?php if (array_search("stock", $access) > -1 || isset($CheckSuperAdmin)) { ?>
			<li class="">
				<a href="stock">
					<i class="menu-icon fa fa-usd"></i>
					<span class="menu-text"> Stock </span>
				</a>
				<b class="arrow"></b>
			</li>
		<?php } ?>


	</ul><!-- /.nav-list -->

<?php } ?>
