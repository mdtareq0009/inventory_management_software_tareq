<div id="rh_screen"></div>
<div id="rh_msgbox" class="rh_msgbox">
	<input type="text" id="rh_txt_505" style="position:absolute;left:0px;top:0px;margin:3px 0 0 0;padding:0px;width:1px;height:1px;border:0px;background:none">
	<div id="rh_msgbox_close" class="rh_msgbox_button rh_msgbox_button_close" onclick="rh_msgbox_close()">X</div>
	<div id="rh_msgbox_text" class="rh_msgbox_text"></div>
</div>
<div id="rh_confirm" class="rh_msgbox">
	<input type="text" id="rh_txt_505" style="position:absolute;left:0px;top:0px;margin:3px 0 0 0;padding:0px;width:1px;height:1px;border:0px;background:none">
	<div id="rh_confirm_yes" class="rh_msgbox_button rh_msgbox_button_yes">Yes</div>
	<div id="rh_confirm_close" class="rh_msgbox_button rh_msgbox_button_no" onclick="rh_confirm_close()">No</div>
	<div id="rh_confirm_text" class="rh_msgbox_text rh_msgbox_text_confirm"></div>
</div>