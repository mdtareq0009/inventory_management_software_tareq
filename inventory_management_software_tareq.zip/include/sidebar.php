<style>
    #sidebar{
        background-color: #333;
    }
    .skin-2 .nav-list>li.active>a{
        
    }
</style>
<div id="sidebar" class="sidebar responsive ace-save-state sidebar-fixed sidebar-scroll">
   
<?php include('menu.php'); ?>

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>
</div>