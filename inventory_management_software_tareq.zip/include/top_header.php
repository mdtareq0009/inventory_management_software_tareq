<?php
$cls_department = new cls_department();
$companyProfile = $cls_department->get_company();
?>
<div id="navbar" class="navbar navbar-default ace-save-state navbar-fixed-top" style="background:#FF742C !important;">
    <div class="navbar-container ace-save-state" id="navbar-container">
        <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
            <span class="sr-only">Toggle sidebar</span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>
        </button>

        <div class="navbar-header pull-left">
            <a href="{{route('dashboard')}}" class="navbar-brand">
                <small>
                    <i class="fa fa-leaf"></i>
                    <?php echo $companyProfile['name'];?>
                </small>
            </a>
        </div>

        <div class="navbar-buttons navbar-header pull-right" role="navigation">
            <ul class="nav ace-nav">

                
                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                                <big>Branch Acess</big>
                            <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                       
                        <li>
                            <a class="btn-add branch-access" href="javascript:" data-id="{{$branch->id}}">
                                <i class="ace-icon fa fa-bank"></i>
                              
                            </a>
                        </li>
                    </ul>
                </li>	

                <li class="clock_li">
                    <a class="clock" style="background:#FF742C !important;">
                        <span style="font-size:20px;"><i class="ace-icon fa fa-clock-o"></i></span> <span style="font-size:15px;"><span id="timer" style="font-size:15px;"></span></span>
                    </a>
                </li>
                


                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle" style="background:#FF742C !important;">
                        <img class="nav-user-photo" src="{{asset('assets/img/no_image.png')}}" alt="" />

                        <span class="user-info">
                            <small>Welcome,</small>
                           
                        </span>

                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        


                        <li>
                            
                            <a href="javascript:" id="logOut">
                                <i class="ace-icon fa fa-power-off"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
