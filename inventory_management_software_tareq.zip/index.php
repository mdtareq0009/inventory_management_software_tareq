<?php 


session_start();

// Check if the session variables 'uid' and 'role' are set and not empty
if (isset($_SESSION['uid']) && !empty($_SESSION['uid']) && isset($_SESSION['role']) && !empty($_SESSION['role'])) {
    // Redirect to the dashboard if session variables are valid
    header('Location: dashboard'); // Ensure the URL is correct
    exit; // Ensure no further code is executed after redirection
} else {
    // Unset and destroy the session if conditions are not met
    session_unset();
    session_destroy();
}

	

require_once('functions/db_config.php');
require_once('functions/cls_department.class.php');
$cls_department = new cls_department();

?>
<!DOCTYPE html>
<html>
<head>
	<?php 
	$companyProfile = $cls_department->get_company();	
	?>
	<title><?php echo $companyProfile['name'];?> || Login Page</title>
	<link rel="stylesheet" type="text/css" href="assets/login/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/login/css/login.css">
	<link rel="icon" type="image/x-icon" href="assets/login/img/favicon.png">
	<script src="assets/js/jquery_2.js"></script>
	<style>
		.typed-cursor{
			color: #fff;
		}
	</style>
	<script> 
     $(function(){
		$('form#LoginForm').on('submit', function(e){
			e.preventDefault();
			var username = $('[name="txt_username"]');
			var password = $('[name="txt_password"]'); 
			
			var dataString = 'username='+username.val()+'&password='+password.val();
			
			if(username.val() == 0){
				alert('Username required please !');
				return;
			}
			if(password.val() == 0){
				alert('Password required please !');
				return;
			}
			
			else{
				$.ajax({
					 type:'post',
					 url:'post_url/user_login.php',
					 data:dataString,
					 success:function(data){
						//alert(data);
						arr = new Array();
						arr = data.split("|");
						if(arr[0] == 0){
							window.location = 'dashboard';
						}
						else{
							alert(arr[1]);
						}
					 },
					 error:function(){
						//alert('Error');
					 }
				});
			}
		});
	});
	</script>
</head>
<body>
<div class="container">
	<div class="contant">
		<div class="login">
			<div class="right-cont">
				<div class="login-form">
					<div class="company-feature">
						<div class="com-image" style="text-align: center">
						
							<?php 
									
								if($companyProfile['logo'] !=null){			
							?>

							<img src="<?php echo $companyProfile['logo'];?>" style="width: 60%;height: 105px; border-radius: 25px;padding-top: 5px;">
							<?php }else{?>
							<img src="assets/login/img/no_image.png" style="width: 60%;height: 105px; border-radius: 25px;padding-top: 5px;">
							<?php } ?>
						</div>
						
					</div>
					<div class="company-info" style="
					font-size: 11px;
					text-align: center;">
					
						<div class="com-add">
							<div class="com-profile">
								<strong>Name</strong> : <?php echo $companyProfile['name'];?> <br>
								<strong>Address</strong> : <?php echo $companyProfile['address'];?> 
							</div>
						</div>
					</div>
					<div class="form">
						<h4>Please Sign In</h4>
						<form method="post" id="LoginForm">
							<div class="form-group">
								<input type="email" name="txt_username" class="form-control"placeholder="email" />
							</div>
							<div class="form-group">
								<input type="password" name="txt_password" class="form-control" placeholder="Password">
							</div>
							<div class="form-group">
								<input type="submit" name="btn_user_login" class="btn btn-success btn-block" value="Login">
							</div>
							<div class="form-group">
							<a href="general_register">New Registration</a> 
							</div>
						</form>
					</div>
					
				</div>
			</div>
	
			<div class="clr"></div>
		</div>
	</div>

</div>

	
<script src="assets/login/js/bootstrap.min.js"></script>
	<script> 
	function showBranch(str){
		var showSection_http = new XMLHttpRequest();
		showSection_http.onload = function(){
			var user = this.responseText;
			document.getElementById("txt_user").innerHTML = user;
		}
		showSection_http.open("POST", "post_url/get_admin_info.php", false);
		showSection_http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		showSection_http.send('str='+str);
	}
	</script>
</body>
</html>


