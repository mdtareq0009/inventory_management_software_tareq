<?php $_SESSION['module'] = 'inventory';
$module = $_SESSION['module']; ?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();


$userID =  $_SESSION['uid'];


$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];



?>
<?php if ($module == 'inventory') { ?>
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<div class="col-md-1"></div>
			<div class="col-md-10">
				<div class="col-md-12 header">

					<h3>Inventory Module </h3>
				</div>
				<?php if (array_search("product", $access) > -1 || isset($CheckSuperAdmin)) { ?>
					<div class="col-md-2 col-xs-6 ">
						<div class="col-md-12 section20">
							<a href="sales/product">
								<div class="logo">
									<i class="menu-icon fa fa-usd"></i>
								</div>
								<div class="textModule">
									Sales Entry
								</div>
							</a>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
<?php } ?>
<?php include('include/footer.php');?>