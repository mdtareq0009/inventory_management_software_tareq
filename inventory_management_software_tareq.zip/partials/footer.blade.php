<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <div class="row">
                <div class="col-md-12" style="padding: 4px 0;background-color: #333;color:white; margin-bottom: -1px;">
                    <span style="font-size: 12px;">
                        Developed by <span class="blue bolder"><a href="#" target="_blank" style="color: white;text-decoration: underline;font-weight: normal;">MD. Tareq</a></span>
                    </span>
                </div>
            </div>
            
        </div>
    </div>
</div>