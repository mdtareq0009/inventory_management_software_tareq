<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();


	$result = $cls_inventory->currentStock();
	 echo json_encode($result);
?>