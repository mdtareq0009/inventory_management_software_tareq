
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();

	$data = $_POST['id'];
	


	$result = $cls_administrator->delete_category($data);

	echo json_encode($result);
	


?>