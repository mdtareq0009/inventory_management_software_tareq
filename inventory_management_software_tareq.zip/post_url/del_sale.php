
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();

	$data = $_POST['id'];
	


	$result = $cls_inventory->delete_sale($data);

	echo json_encode($result);
	


?>