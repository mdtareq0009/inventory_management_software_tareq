
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();

	$data = json_decode($_POST['data']);


	$result = $cls_administrator->delete_supplier($data);

	echo json_encode($result);
	


?>