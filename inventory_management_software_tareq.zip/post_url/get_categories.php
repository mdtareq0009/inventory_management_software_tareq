<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();

	
	$result = $cls_administrator->get_category();
	 echo json_encode($result);
?>