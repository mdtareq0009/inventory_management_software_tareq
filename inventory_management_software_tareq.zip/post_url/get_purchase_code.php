<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();
	// $sid = "$_POST[id]";
	
	$result = $cls_inventory->get_purchase_code();
	 echo $result;
?>