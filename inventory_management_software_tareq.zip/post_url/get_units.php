<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	// $sid = "$_POST[id]";
	
	$result = $cls_administrator->get_unit();
	 echo json_encode($result);
?>