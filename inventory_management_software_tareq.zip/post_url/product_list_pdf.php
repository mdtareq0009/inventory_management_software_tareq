

<?php
	require_once ('../dompdf/autoload.inc.php');
	require_once('../functions/db_config.php');

	use Dompdf\Dompdf;
	use Dompdf\Options;
	$dbClass = new dbClass();

	$con = $dbClass->connection();


	$result = $con->query("SELECT
	p.*,
	c.name as category_name,
	u.name as unit_name,
	CONCAT(p.name, ' - ', p.product_code) AS display_text
	FROM products p
	LEFT JOIN categories c ON p.category_id = c.id
	LEFT JOIN units u ON p.unit_id = u.id
	WHERE p.deleted_at IS NULL
	ORDER BY p.id DESC")->fetch_all(MYSQLI_ASSOC);

      

$options = new Options();
$options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
$options->set('isPhpEnabled', true); // Enable PHP in HTML (if needed, be cautious with this setting)
$dompdf = new Dompdf($options);


?>


<?php
	$html = '<style >
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
</style><div class="row">
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<h3 style="text-align:center"> Product List</h3>
           
				<table class="record-table">
					<thead>
						<tr>
							<th>Product Code</th>
							<th>Name</th>
							<th>Category</th>
							<th>Unit</th>
							<th>Purchase Price</th>
							<th>Sale Price</th>
							<th>Reorder Level</th>
						</tr>
					</thead>
					<tbody>';

                  foreach ($result as $k => $r) {
						 $html .= '<tr>';
						$html .= '<td>' . htmlspecialchars($r['product_code']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['name']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['category_name']) . '</td>'; 
						$html .= '<td>' . htmlspecialchars($r['unit_name']) . '</td>'; 
						$html .= '<td style="text-align:right">' . htmlspecialchars($r['purchase_price']) . '</td>'; 
						$html .= '<td style="text-align:right">' . htmlspecialchars($r['sale_price']) . '</td>'; 
						$html .= '<td style="text-align:right">' . htmlspecialchars($r['reorder_level']) . '</td>'; 
						$html .= '</tr>';
					};
					
// Append the footer and table closing tags
$html .= '</tbody>
</table>         
</div>
</div>
</div>';
		
				
						


$dompdf->loadHtml($html);

// (Optional) Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF (1 = download and 0 = view in browser)
$dompdf->stream('purcahse_record.pdf', array('Attachment' => 0));
print_r($html);
exit;

	?>