

<?php
	require_once ('../dompdf/autoload.inc.php');
	require_once('../functions/db_config.php');

	use Dompdf\Dompdf;
	use Dompdf\Options;
	$dbClass = new dbClass();

	$con = $dbClass->connection();


	$sid =  isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
	$fromdata = $_GET['dateFrom'];
	$todate = $_GET['dateTo'];
	$with_details = isset($_GET['with_details']) ? $_GET['with_details'] : null;


        // $supplierId = $con()->real_escape_string($sid);
        // $dateFrom = $con()->real_escape_string($fromdata);
        // $dateTo = $con()->real_escape_string($todate);
        // $with_details = $con()->real_escape_string($with_details);

	
        $clauses = "";
        if(isset($fromdata) && $fromdata != '' && isset($todate) && $todate != ''){
            $clauses .= " and pm.order_date between '$fromdata' and '$todate'";
        }
        
        if(isset($sid) && $sid != ''){
            $clauses .= " and pm.supplier_id = '$sid'";
        }


		
		$purchases = $con->query("SELECT
		concat(pm.invoice_number, ' - ', s.name) as display_name,
		pm.*,
		s.name as supplier_name,
		s.mobile as supplier_mobile,
		s.supplier_code as code,
		s.address as supplier_address
		from purchases pm
		join suppliers s on s.id = pm.supplier_id
		where pm.status = 'a'
		and pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);

      

$options = new Options();
$options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
$options->set('isPhpEnabled', true); // Enable PHP in HTML (if needed, be cautious with this setting)
$dompdf = new Dompdf($options);


?>


<?php
	$html = '<style >
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
</style><div class="row">
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<h3 style="text-align:center"> Purchsae Record</h3>
           
				<table class="record-table">
					<thead>
						<tr>
							<th>Invoice No.</th>
							<th>Date</th>
							<th>Supplier Name</th>
							<th>Total</th>
							<th>Note</th>
						</tr>
					</thead>
					<tbody>';
			
                  foreach ($purchases as $k => $r) {
						 $html .= '<tr>';
						$html .= '<td>' . htmlspecialchars($r['invoice_number']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['order_date']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['display_name']) . '</td>'; 
						$html .= '<td style="text-align:right;">' . number_format($r['total'], 2) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['remark']) . '</td>';
						$html .= '</tr>';
					};
					$total = number_format(array_sum(array_column($purchases, 'total')), 2); // Example of calculating total

// Append the footer and table closing tags
$html .= '</tbody>
    <tfoot>
        <tr style="font-weight:bold;">
            <td colspan="3" style="text-align:right;">Total</td>
            <td style="text-align:right;">' . htmlspecialchars($total) . '</td>
            <td></td>
        </tr>
    </tfoot>
</table>         
</div>
</div>
</div>';
		
				
						


$dompdf->loadHtml($html);

// (Optional) Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF (1 = download and 0 = view in browser)
$dompdf->stream('purcahse_record.pdf', array('Attachment' => 0));
print_r($html);
exit;

	?>