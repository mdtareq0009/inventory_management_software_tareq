

<?php

/////create PDF File
	require_once ('../dompdf/autoload.inc.php');
	require_once('../functions/db_config.php');

	use Dompdf\Dompdf;
	use Dompdf\Options;
	$dbClass = new dbClass();

	$con = $dbClass->connection();


	$sid =  isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
	$fromdata = $_GET['dateFrom'];
	$todate = $_GET['dateTo'];
	$with_details = isset($_GET['with_details']) ? $_GET['with_details'] : null;


   
	
	$clauses = "";
	if(isset($dateFrom) && $dateFrom != '' && isset($dateTo) && $dateTo != ''){
		$clauses .= " and pm.order_date between '$dateFrom' and '$dateTo'";
	}
	
	if(isset($customer_id) && $customer_id != ''){
		$clauses .= " and pm.customer_id = '$customer_id'";
	}

		$sale = $con->query("SELECT
		concat(pm.invoice_number, ' - ', c.name) as display_name,
		pm.*,
		c.name as customer_name,
		c.mobile as customer_mobile,
		c.customer_code as code,
		c.address as customer_address
		from sales pm
		join customers c on c.id = pm.customer_id
		where pm.deleted_at IS NULL
		$clauses
		order by pm.id desc
	")->fetch_all(MYSQLI_ASSOC);

      

$options = new Options();
$options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
$options->set('isPhpEnabled', true); // Enable PHP in HTML (if needed, be cautious with this setting)
$dompdf = new Dompdf($options);


?>


<?php
	$html = '<style >
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
</style><div class="row">
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<h3 style="text-align:center"> Sale Record</h3>
           
				<table class="record-table">
					<thead>
						<tr>
							<th>Invoice No.</th>
							<th>Date</th>
							<th>Customer Name</th>
							<th>Total</th>
							<th>Note</th>
						</tr>
					</thead>
					<tbody>';
			
                  foreach ($sale as $k => $r) {
						 $html .= '<tr>';
						$html .= '<td>' . htmlspecialchars($r['invoice_number']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['order_date']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['display_name']) . '</td>'; 
						$html .= '<td style="text-align:right;">' . number_format($r['total'], 2) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['remark']) . '</td>';
						$html .= '</tr>';
					};
					$total = number_format(array_sum(array_column($sale, 'total')), 2); // Example of calculating total

// Append the footer and table closing tags
$html .= '</tbody>
    <tfoot>
        <tr style="font-weight:bold;">
            <td colspan="3" style="text-align:right;">Total</td>
            <td style="text-align:right;">' . htmlspecialchars($total) . '</td>
            <td></td>
        </tr>
    </tfoot>
</table>         
</div>
</div>
</div>';
		
				
						


$dompdf->loadHtml($html);

// (Optional) Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF (1 = download and 0 = view in browser)
$dompdf->stream('Sale_record.pdf', array('Attachment' => 0));
print_r($html);
exit;

	?>