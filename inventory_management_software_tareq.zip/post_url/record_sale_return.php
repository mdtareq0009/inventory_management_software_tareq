
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();

	$userId = isset($_POST['id']) ? $_POST['id'] : null;
	$customer_id = $_POST['customer_id'];
	$dateFrom = isset($_POST['dateFrom'])? $_POST['dateFrom'] : null;
	$dateTo = isset($_POST['dateTo'])  ? $_POST['dateTo'] : null;
	$with_details = isset($_POST['with_details']) ? $_POST['with_details'] : null;


	
	$result = $cls_inventory->sale_return_record($userId,$customer_id,$dateFrom,$dateTo,$with_details);

	echo json_encode($result);

?>