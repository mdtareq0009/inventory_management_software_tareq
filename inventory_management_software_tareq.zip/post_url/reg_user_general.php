
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['users']);

	
	$result = $cls_administrator->user_reg_general($data);
	echo json_encode($result);
	
	
	
	


?>