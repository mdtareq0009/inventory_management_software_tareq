

<?php
	require_once ('../dompdf/autoload.inc.php');
	require_once('../functions/db_config.php');

	use Dompdf\Dompdf;
	use Dompdf\Options;
	$dbClass = new dbClass();

	$con = $dbClass->connection();

	
	$productId =  isset($_GET['productId']) ? $_GET['productId'] : null;
	$categoryId =  isset($_GET['catId']) ? $_GET['catId'] : null;
	$date =  isset($_GET['date']) ? $_GET['date'] : null;
	$searchTypes = $_GET['searchTypes'];

if($searchTypes !='current'){


	$clauses = "";
	if($searchTypes == 'category'){
		if($categoryId != null){
			$clauses .= " and p.category_id  = '$categoryId'";
		}
	}
	if($searchTypes == 'product'){
		if($productId != null){
			$clauses .= " and p.id = '$productId'";
		}
	}
	$stock =  $con->query("
	SELECT
		p.*,
		pc.name as category_name,
		u.name as unit_name,
		(SELECT ifnull(sum(pd.quantity), 0) 
			from purchase_details pd 
			left join purchases pr on pr.id = pd.purchase_id
			where pd.product_id = p.id
			and pd.deleted_at is null
			" . (isset($date) && $date != null ? " and pr.order_date <= '$date'" : "") . "
		) as purchased_quantity,

		(SELECT ifnull(sum(prd.quantity), 0) 
			from purchase_return_details prd 
			left join purchase_returns pr on pr.id = prd.purchase_return_id 
			where prd.product_id = p.id
			and prd.deleted_at is null
			" . (isset($date) && $date != null ? " and pr.return_date <= '$date'" : "") . "
		) as purchased_return_quantity,
				
		(SELECT ifnull(sum(sd.quantity), 0) 
			from sale_details sd
			left join sales s on s.id = sd.sale_id
			where sd.product_id = p.id
			and sd.deleted_at is null
			" . (isset($date) && $date != null ? " and s.order_date <= '$date'" : "") . "
		) as sold_quantity,

		(SELECT ifnull(sum(isrud.quantity), 0) 
			from sale_return_details isrud
			left join sale_returns sr on sr.id = isrud.sale_return_id
			where isrud.product_id = p.id
			and isrud.deleted_at is null
			" . (isset($date) && $date != null ? " and sr.return_date <= '$date'" : "") . "
		) as sale_return_quantity,

		(SELECT (purchased_quantity + sale_return_quantity) - (sold_quantity  + purchased_return_quantity)) as current_quantity,
		(SELECT p.purchase_price * current_quantity) as stock_value
	from products p
	left join categories pc on pc.id = p.category_id
	left join units u on u.id = p.unit_id
	where p.deleted_at is null
	$clauses
")->fetch_all(MYSQLI_ASSOC);
}else{
	$stock = $con->query("SELECT * from(
		SELECT
			ci.*,
			(select (ci.purchase_quantity + ci.sale_return_quantity ) - (ci.sale_quantity + ci.purchase_return_quantity)) as current_quantity,
			p.name as product_name,
			p.product_code as product_code,
			pc.name as category_name,
			u.name as unit_name
		from stocks ci
		left join products p on p.id = ci.product_id
		left join categories pc on pc.id = p.category_id
		left join units u on u.id = p.unit_id
		where p.deleted_at is null
	) as tbl
	where 1 = 1
	and current_quantity > 0
	order by product_id asc
")->fetch_all(MYSQLI_ASSOC);
}

	
      

$options = new Options();
$options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
$options->set('isPhpEnabled', true); // Enable PHP in HTML (if needed, be cautious with this setting)
$dompdf = new Dompdf($options);


?>


<?php

if($searchTypes != 'current'){
	$html = '<style >
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
</style><div class="row">
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<h3 style="text-align:center"> Total Stock</h3><table class="record-table">
			   <thead>
			   <tr>
					<th>Product Id</th>
					<th>Product Name</th>
					<th>Category</th>
					<th>Purchased Quantity</th>
					<th>Purchase Returned Quantity</th>
					<th>Sale Quantity</th>
					<th>Sale Returned Quantity</th>
					<th>Current Quantity</th>
			   </tr>
			   </thead>
			   <tbody>';

			 
			   foreach ($stock as $k => $r) {
				   $html .= '<tr>';
						$html .= '<td>' . htmlspecialchars($r['product_code']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['name']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['category_name']) . '</td>'; 
						$html .= '<td>' . htmlspecialchars($r['purchased_quantity']) . '</td>'; 
						$html .= '<td>' . htmlspecialchars($r['purchased_return_quantity']) . '</td>'; 
						$html .= '<td>' . htmlspecialchars($r['sold_quantity']) . '</td>'; 
						$html .= '<td>' . htmlspecialchars($r['sale_return_quantity']) . '</td>'; 
						$html .= '<td style="text-align:right;">' . number_format($r['current_quantity'], 2) . '</td>';
						$html .= '</tr>';
					};
				

// Append the footer and table closing tags
$html .= '</tbody>
</table>         
</div>
</div>
</div>';
}else{
	$html = '<style >
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
</style><div class="row">
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<h3 style="text-align:center"> Current Stock</h3><table class="record-table">
			   <thead>
			   <tr>
			   <th>Product Code</th>
			   <th>Product Name</th>
			   <th>Category Name</th>
			   <th>Current Quantity</th>
			   </tr>
			   </thead>
			   <tbody>';
			   
			   foreach ($stock as $k => $r) {
				   $html .= '<tr>';
						$html .= '<td>' . htmlspecialchars($r['product_code']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['product_name']) . '</td>';
						$html .= '<td>' . htmlspecialchars($r['category_name']) . '</td>'; 
						$html .= '<td style="text-align:right;">' . number_format($r['current_quantity'], 2) . '</td>';
						$html .= '</tr>';
					};
				

// Append the footer and table closing tags
$html .= '</tbody>
</table>         
</div>
</div>
</div>';
}
				
						


$dompdf->loadHtml($html);

// (Optional) Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF (1 = download and 0 = view in browser)
$dompdf->stream('purcahse_record.pdf', array('Attachment' => 0));
print_r($html);
exit;

	?>