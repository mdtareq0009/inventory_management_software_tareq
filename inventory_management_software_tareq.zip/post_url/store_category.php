
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['category']);
	$quaryType =  json_decode($_POST['quaryType']); 

	if($quaryType =='addCategory'){
		$result = $cls_administrator->store_category($data);
		echo json_encode($result);
	}
	if($quaryType =='updateCategory'){
		
		$result = $cls_administrator->update_category($data);
		echo json_encode($result);
	}
	
	


?>