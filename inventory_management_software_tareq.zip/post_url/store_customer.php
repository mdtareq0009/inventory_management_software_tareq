
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['customers']);
	$quaryType =  json_decode($_POST['quaryType']); 

	if($quaryType =='addcustomer'){
		$result = $cls_administrator->store_customer($data);
		echo json_encode($result);
	}
	if($quaryType =='updatecustomer'){
		
		$result = $cls_administrator->update_customer($data);
		echo json_encode($result);
	}
	
	


?>