
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['products']);
	$quaryType =  json_decode($_POST['quaryType']); 

	if($quaryType =='addProduct'){
		$result = $cls_administrator->store_product($data);
		echo json_encode($result);
	}
	if($quaryType =='updateProduct'){
		
		$result = $cls_administrator->update_product($data);
		echo json_encode($result);
	}
	
	


?>