
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();
	
	$data = json_decode($_POST['sale']);
	$cart = json_decode($_POST['cartProducts']);
	$quaryType =  json_decode($_POST['quaryType']); 


	if($quaryType =='addSale'){
		

		$result = $cls_inventory->store_sale($data,$cart);
		echo json_encode($result);
	}
	if($quaryType =='updateSale'){
		
		$result = $cls_inventory->update_sale($data,$cart);
		
		echo json_encode($result);
	}
	
	


?>