
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['suppliers']);
	$quaryType =  json_decode($_POST['quaryType']); 

	if($quaryType =='addsupplier'){
		$result = $cls_administrator->store_supplier($data);
		echo json_encode($result);
	}
	if($quaryType =='updatesupplier'){
		
		$result = $cls_administrator->update_supplier($data);
		echo json_encode($result);
	}
	
	


?>