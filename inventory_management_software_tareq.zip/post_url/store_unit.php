
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$data = json_decode($_POST['units']);
	$quaryType =  json_decode($_POST['quaryType']); 

	if($quaryType =='addUnit'){
		$result = $cls_administrator->store_unit($data);
		echo json_encode($result);
	}
	if($quaryType =='updateUnit'){
		
		$result = $cls_administrator->update_unit($data);
		echo json_encode($result);
	}
	
	


?>