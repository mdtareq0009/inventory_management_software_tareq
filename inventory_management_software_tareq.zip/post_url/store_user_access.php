
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();
	
	$id = $_POST['id'];
	$access = $_POST['access'];
	$created_by = $_POST['created_by'];


	$result = $cls_administrator->user_access_store($id,$access,$created_by);
	echo json_encode($result);
	
	
	


?>