<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_inventory.class.php');
	$dbClass = new dbClass();

	$cls_inventory = new cls_inventory();

	
	$searchTypes = isset($_POST['searchTypes'])? $_POST['searchTypes'] : '';
	$category_id = isset($_POST['category_id'])? $_POST['category_id'] : '';
	$product_id =  isset($_POST['product_id'])? $_POST['product_id'] : '' ;
	$date = isset($_POST['date'])? $_POST['date'] : null;

	$result = $cls_inventory->totalStock($searchTypes,$product_id,$category_id,$date);
	 echo json_encode($result);
?>