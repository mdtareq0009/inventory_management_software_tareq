
<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_administrator.class.php');
	$dbClass = new dbClass();

	$cls_administrator = new cls_administrator();

	$data = $_POST['id'];
	$status = $_POST['status'];
	$created_by = $_POST['created_by'];
	


	$result = $cls_administrator->user_active($data,$status,$created_by);

	echo json_encode($result);
	


?>