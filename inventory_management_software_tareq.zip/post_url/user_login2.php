<?php
	require_once('../functions/db_config.php');
	require_once("../functions/cls_admin_users.class.php");

	$cls_admin_users = new cls_admin_users();
	$branch_code = "$_POST[branch_code]";
	$password = "$_POST[password]";
	
	$result = $cls_admin_users->user_login2($branch_code, $password);
	echo $result;
?>