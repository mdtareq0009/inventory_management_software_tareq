<?php
	require_once('../functions/db_config.php');
	require_once('../functions/cls_voucher.class.php');

	$cls_voucher = new cls_voucher();
	$id = "$_POST[id]";
	
	$result = $cls_voucher->slct_voucher($id);
	echo $result;
?>