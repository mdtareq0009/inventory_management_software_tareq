<?php 
$_SESSION['module'] = 'Administration';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];
?>


<style>
	.v-select{
		margin-bottom: 5px;
	}
	.v-select.open .dropdown-toggle{
		border-bottom: 1px solid #ccc;
	}
	.v-select .dropdown-toggle{
		padding: 0px;
		height: 25px;
	}
	.v-select input[type=search], .v-select input[type=search]:focus{
		margin: 0px;
	}
	.v-select .vs__selected-options{
		overflow: hidden;
		flex-wrap:nowrap;
	}
	.v-select .selected-tag{
		margin: 2px 0px;
		white-space: nowrap;
		position:absolute;
		left: 0px;
	}
	.v-select .vs__actions{
		margin-top:-5px;
	}
	.v-select .dropdown-menu{
		width: auto;
		overflow-y:auto;
	}
	#products label{
		font-size:13px;
	}
	#products select{
		border-radius: 3px;
	}
	#products .add-button{
		padding: 2.5px;
		width: 28px;
		background-color: #298db4;
		display:block;
		text-align: center;
		color: white;
	}
	#products .add-button:hover{
		background-color: #41add6;
		color: white;
	}
</style>

    <div id='products'>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Product  Entry</h5>
                        </div>

                        <div class="widget-body" style="background-color: #f1f1f1;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Product Code </label>
                                            <div class="col-xs-8">
                                                <input type="text" name="employee_code" class="form-control" v-model="product.product_code" readonly />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> product Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Product Name" class="form-control" v-model="product.name" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Category </label>
                                            <div class="col-xs-7">
                                                <v-select :options="categories" label="name" v-model="selectedCategory"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                <a href="/category_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Unit </label>
                                            <div class="col-xs-7">
                                                <v-select :options="units" label="name" v-model="selectedUnit"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                <a href="/unit_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-6">
                                         <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Re-order Level </label>
                                            <div class="col-xs-8">
                                                <input type="number" placeholder="Re-order Level" class="form-control" v-model="product.reorder_level" required/>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Purchase Price </label>
                                            <div class="col-xs-8">
                                                <input type="number" step="0.01" placeholder="Purchase Price"  class="form-control" v-model="product.purchase_price" required/>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Sale Price </label>
                                            <div class="col-xs-8">
                                                <input type="number" step="0.01" placeholder="Sale Price"  class="form-control" v-model="product.sale_price" required/>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="products" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row }">
                            <tr class="hover-tr">
                                <td>{{ row.product_code }}</td>
                                <td>{{ row.display_text }}</td>
                                <td>{{ row.category_name }}</td>
                                <td>{{ row.unit_name }}</td>
                                <td>{{ row.reorder_level }}</td>
                                <td>{{ row.purchase_price }}</td>
                                <td>{{ row.sale_price }}</td>
                                <td>
									<?php if($_SESSION['role'] !="General"){?>
                                        <a class="blue" href="javascript:" @click="editProduct(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteProduct(row)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
										<?php } ?>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>


<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="assets/js/vue/vue-select.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	Vue.component('v-select', VueSelect.VueSelect);
	new Vue({
		el: '#products',
		data () {
        return {
            product: {
                id              : '',
                product_code   : '',
                category_id     : '',
                unit_id         : '',
                name            : '',
                purchase_price  : '',
                sale_price      : '',
                reorder_level   : 0,
                created_by   : '<?php echo $_SESSION['uid']?>',
            },

            products      : [],

            categories      : [],
            selectedCategory: null,          

            units       : [],
            selectedUnit: null,

            columns: [
                { label: 'Product Code', field: 'product_code', align: 'center'},
                { label: 'Name', field: 'name', align: 'center' },
                { label: 'Category', field: 'category_name', align: 'center' },
                { label: 'Unit', field: 'unit_name', align: 'center' },
                { label: 'Re-order Level', field: 'reorder_level', align: 'center' },
                { label: 'Purchase Price', field: 'purchase_price', align: 'center' },
                { label: 'Sale Price', field: 'sale_price', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getProducts();
        this.getCategories();
        this.getUnits();
        this.getProductCode();
    },
    methods: {

        getCategories(){
            
            axios.get('post_url/get_categories').then(res=>{
                this.categories = res.data;
            })
        },

        getUnits(){
            axios.get('post_url/get_units').then(res=>{
                this.units = res.data;
            })
        },

        getProducts(){
            axios.get('post_url/get_product').then(res=>{
                this.products = res.data;
				console.log(this.products);
				
            })
        },

        getProductCode(){
            axios.get('post_url/get_product_code').then(res=>{
                this.product.product_code = res.data;
            })
        },
       

        save(){

            if(this.selectedCategory == null){
                alert('Select Category');
                return;
            }
            
            if(this.selectedUnit == null){
                alert('Select Unit');
                return;
            }
           

            this.progress = true;

            this.product.category_id = this.selectedCategory.id;
            this.product.unit_id = this.selectedUnit.id;


            let url = 'post_url/store_product';
            let quaryType = 'addProduct';

            if(this.product.id != ''){
                 quaryType = 'updateProduct';
            }
           
            
            let fd = new FormData();
            fd.append('products', JSON.stringify(this.product));
            fd.append('quaryType', JSON.stringify(quaryType));
            axios.post(url, fd).then(res=>{
                console.log(res.data);
                    this.progress = false;
                    alert(res.data.message);
					if(res.data.success){
                        this.progress = false;
                        this.clear();
                        this.getProductCode();
                        this.getProducts();
					}else{
                        this.progress = false;
                    }
                   
               
                
            })
        },
        clear(){
        
            this.product = {
                id             : '',
                product_code: '',
                category_id    : '',
                unit_id        : '',
                name           : '',
                purchase_price : 0,
                sale_price     : 0,
                reorder_level  : 0,
            };
           this.selectedCategory = null;
           this.selectedUnit     = null;
        },
        
     
        editProduct(row){
             
            
            this.selectedCategory = {
                id  : row.category_id,
                name: row.category_name
            }

          
            this.selectedUnit = {
                id  : row.unit_id,
                name: row.unit_name
            }
             
          
            this.product = {
                id            : row.id,
                product_code  : row.product_code,
                name          : row.name,
                unit_id       : row.unit_id,
                category_id   : row.category_id,
                purchase_price: row.purchase_price,
                sale_price    : row.sale_price,
                reorder_level : row.reorder_level,
                created_by    : row.created_by,
            }

        },
        deleteProduct(data){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
                }).then((result) => {
                if (result.isConfirmed) {
                    let fd = new FormData();
                    fd.append('data', JSON.stringify(data));
            
                    axios.post('post_url/del_product', fd).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getProductCode();
                        this.getProducts();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
	})
</script>

<?php include('include/footer.php');?>