<?php 
$_SESSION['module'] = 'inventory';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];
?>


<style>
	.v-select{
		margin-bottom: 5px;
	}
	.v-select.open .dropdown-toggle{
		border-bottom: 1px solid #ccc;
	}
	.v-select .dropdown-toggle{
        width: 150px;
        background-color: white;
        padding: 0px;
		height: 25px;
	}
	.v-select input[type=search], .v-select input[type=search]:focus{
		margin: 0px;
	}
	.v-select .vs__selected-options{
		overflow: hidden;
		flex-wrap:nowrap;
	}
	.v-select .selected-tag{
		margin: 2px 0px;
		white-space: nowrap;
		position:absolute;
		left: 0px;
	}
	.v-select .vs__actions{
		margin-top:-5px;
	}
	.v-select .dropdown-menu{
		width: auto;
		overflow-y:auto;
	}
	#purchase label{
		font-size:13px;
	}
	#purchase select{
		border-radius: 3px;
        padding: 0px;
	}
	#purchase .add-button{
		padding: 2.5px;
		width: 28px;
		background-color: #298db4;
		display:block;
		text-align: center;
		color: white;
	}
	#purchase .add-button:hover{
		background-color: #41add6;
		color: white;
	}

    #searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
	.record-table{
		width: 100%;
		border-collapse: collapse;
	}
	.record-table thead{
		background-color: #0097df;
		color:white;
	}
	.record-table th, .record-table td{
		padding: 3px;
		border: 1px solid #454545;
	}
    .record-table th{
        text-align: center;
    }
	th{
		background-color: #146C94;
	color:#fff !important;
	}
	.table-responsive tr{
		background-color: #E3F4F4 !important;
	-webkit-transition: .5s all;   
		-webkit-transition-delay: .05s; 
		-moz-transition: .5s all;   
		-moz-transition-delay: .05s; 
		-ms-transition: .5s all;   
		-ms-transition-delay: .05s; 
		-o-transition: .5s all;   
		-o-transition-delay: .05s; 
		transition: .5s all;   
		transition-delay: .05s; 
	}
	.table-responsive tr:hover{
	background-color: #62CDFF !important;
	transition: 0s all;   
	-webkit-transition-delay: 0s;
		-moz-transition-delay: 0s;
		-ms-transition-delay: 0s;
		-o-transition-delay: 0s;
		transition-delay: 0s;
}

.excel-design{
	margin-left: 5px;
    background: #008a00;
    padding: 5px;
    border: none;
    /* outline: aliceblue; */
    color: white;
    border-radius: 5px;
}
.print-design{
	margin-left: 5px;
    background: #f51010;
    padding: 5px;
    border: none;
    /* outline: aliceblue; */
    color: white;
    border-radius: 5px;
}
.pdf-design{
	margin-left: 5px;
    background: #106ff5;
    padding: 5px;
    border: none;
    /* outline: aliceblue; */
    color: white;
    border-radius: 5px;
}

</style>
<div id="salereturns">
	<div class="row" style="border-bottom: 1px solid #ccc;padding: 3px 0;background: aquamarine;">
		<div class="col-md-12">
			<form class="form-inline" id="searchForm" @submit.prevent="getSearchResult">
				<div class="form-group">
					<label>Search Type</label><br>
					<select class="form-control" v-model="searchType" @change="onChangeSearchType">
						<option value="">All</option>
						<option value="customer">By Customer</option>
					</select>
				</div>

				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'customer' && customers.length > 0 ? '' : 'none'}">
					<label>Customer</label>
					<v-select v-bind:options="customers" v-model="selectedCustomer" label="name"></v-select>
				</div>

				<div class="form-group" v-bind:style="{display: searchTypesForRecord.includes(searchType) ? '' : 'none'}">
					<label>Record Type</label><br>
					<select class="form-control" v-model="recordType" @change="salereturns = []">
						<option value="without_details">Without Details</option>
						<option value="with_details">With Details</option>
					</select>
				</div>

				<div class="form-group">
					<label>From Date</label><br>
					<input type="date" class="form-control" v-model="dateFrom">
				</div>

				<div class="form-group">
					<label>To Date</label><br>
					<input type="date" class="form-control" v-model="dateTo">
				</div>

				<div class="form-group" style="margin-top: 18px;">
					<input type="submit" value="Search">
				</div>
			</form>
		</div>
	</div>

	<div class="row" style="margin-top:15px;display:none;" v-bind:style="{display: salereturns.length > 0 ? '' : 'none'}">
		<div class="col-md-12" style="margin-bottom: 10px;">

			<a href="" @click.prevent="print"><button class="print-design">
					<i class="fa fa-print"></i> Print
				</button>
				</a>
			<button class="excel-design" @click="exportTableToExcel('reportContent', 'Sales Return Record','Sales Return Record')">
				<i class="fa fa-file-excel-o"></i> Export To Excel
   		 	</button>
		</div>
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				
				<table  
					class="record-table" 
					v-if="(searchTypesForRecord.includes(searchType)) && recordType == 'with_details'" 
					style="display:none" 
					v-bind:style="{display: (searchTypesForRecord.includes(searchType)) && recordType == 'with_details' ? '' : 'none'}"
					>
					<thead>
						<tr>
							<th>Invoice No.</th>
							<th>Date</th>
							<th>Customer Name</th>
							<th>Product Name</th>
							<th>Retunr Price</th>
							<th>Quantity</th>
							<th>Total</th>
							<th >Action</th>
						</tr>
					</thead>
					<tbody v-for="(salereturn, sl) in salereturns" :key="sl">
    					<!-- Main Purchase Row -->
							<tr>
								<td>{{ salereturn.invoice_number }}</td>
								<td>{{ salereturn.return_date }}</td>
								<td>{{ salereturn.display_name }}</td>
								<td>{{ salereturn.sale_return_details[0].product_name }}</td>
								
								<td style="text-align:right;">
									{{ salereturn.sale_return_details[0].return_rate }}
								</td>
								<td style="text-align:center;">
									{{ salereturn.sale_return_details[0].quantity }}
								</td>
								<td style="text-align:right;">
									{{ salereturn.sale_return_details[0].total_amount }}
								</td>
								<td>
										<a href="javascript:;" @click="navigateToEditPage(salereturn.id)" title="Edit Sale Return"><i class="fa fa-edit"></i></a>
										<a href="javascript:;" title="Delete Sale Return" @click.prevent="deleteSaleReturn(salereturn.id)">
											<i class="fa fa-trash"></i>
										</a>
										
								</td>
							</tr>
							
							<!-- Additional Products Rows -->
							<tr v-for="(product, index) in salereturn.sale_return_details.slice(1)" :key="index">
								<td v-if="index === 0" colspan="3" :rowspan="salereturn.sale_return_details.length - 1"></td>
								<td>{{ product.product_name }}</td>
								<td style="text-align:right;">
									{{ product.return_rate }}
								</td>
								<td style="text-align:center;">
									{{ product.quantity }}
								</td>
								<td style="text-align:right;">
									{{ product.total_amount }}
								</td>
								<td ></td>
							</tr>
							
							<!-- Summary Row -->
							<tr style="font-weight:bold;">
								<td colspan="5" style="font-weight:normal;">
									<strong>Note:</strong> {{ salereturn.remark }}
								</td>
								<td style="text-align:center;">
									Total Quantity: <br>
									{{ salereturn.sale_return_details.reduce((prev, curr) => prev + parseFloat(curr.quantity), 0) }}
								</td>
								<td style="text-align:right;">
									Total: {{ salereturn.total_amount }}
								</td>
								<td ></td>
							</tr>
						</tbody>
				</table>

				<table 
					class="record-table" 
					v-if="(searchTypesForRecord.includes(searchType)) && recordType == 'without_details'" 
					style="display:none" 
					v-bind:style="{display: (searchTypesForRecord.includes(searchType)) && recordType == 'without_details' ? '' : 'none'}"
					>
					<thead>
						<tr>
							<th>Invoice No.</th>
							<th>Date</th>
							<th>Customer Name</th>
							<th>Total</th>
							<th>Note</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(salereturn,sl) in salereturns" :key='sl'>
							<td>{{ salereturn.invoice_number }}</td>
							<td>{{ salereturn.return_date }}</td>
							<td>{{ salereturn.display_name }}</td>
							<td style="text-align:right;">{{ salereturn.total_amount }}</td>
							<td style="text-align:left;">{{ salereturn.remark }}</td>
							<td style="text-align:center;" >
								<a href="javascript:;" @click="navigateToEditPage(salereturn.id)" title="Edit Purchase"><i class="fa fa-edit"></i></a>
								<a href="javascript:;" title="Delete Purchase" @click.prevent="deleteSaleReturn(salereturn.id)">
									<i class="fa fa-trash"></i>
								</a>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr style="font-weight:bold;">
							<td colspan="3" style="text-align:right;">Total</td>
							<td style="text-align:right;">{{ salereturns.reduce((prev, curr)=>{return prev + parseFloat(curr.total_amount)}, 0) }}</td>
							<td></td>
							<td ></td>
						</tr>
					</tfoot>
				</table>

				
			</div>
		</div>
	</div>
</div>

<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="assets/js/vue/vue-select.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	Vue.component('v-select', VueSelect.VueSelect);
	new Vue({
		el: '#salereturns',
		data(){
			return {
				searchType: '',
				recordType: 'without_details',
				dateFrom: moment().format('YYYY-MM-DD'),
				dateTo: moment().format('YYYY-MM-DD'),
				customers: [],
				selectedCustomer: null,
				salereturns: [],
				campany: [],
				searchTypesForRecord: ['', 'user', 'customer']
			}
		},
        created(){
            this.getCompanyInfo();
        },
		methods: {
			onChangeSearchType(){
				this.salereturns = [];

				 if(this.searchType == 'customer'){
					this.getCustomers();
				}
			},
			
			getCompanyInfo(){
                axios.get('post_url/get_company').then(res=>{
                    this.campany = res.data;
                })
            },
		
			getCustomers(){
				axios.get('post_url/get_customers').then(res => {
					this.customers = res.data;
					console.log(this.customers);
				})
			},
			


			getSearchResult(){
				if(this.searchType != 'customer'){
					this.selectedCustomer = null;
				}
					this.getSaleReturnRecord();
				
			},

			
			navigateToEditPage(id) {
				const baseUrl = 'sales_return';
				let params = {
					id: id
				}
			const queryString = Object.keys(params)
				.map(key => encodeURIComponent(key) + '=' + encodeURIComponent(params[key]))
				.join('&');

			window.location.href = `${baseUrl}?${queryString}`;
			},
			getSaleReturnRecord(){
                const formData = new FormData();
                    formData.append('customer_id', this.selectedCustomer == null ? '' : this.selectedCustomer.id);
                    formData.append('dateFrom', this.dateFrom);
                    formData.append('dateTo', this.dateTo);

                if(this.recordType == 'with_details'){
                    let with_details = true;
                    formData.append('with_details', with_details);
                }

				let url = 'post_url/record_sale_return';
				

				axios.post(url, formData)
				.then(res => {
						this.salereturns = res.data;
				})
				.catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},

			exportTableToExcel(transactionsTable, filename = '',headerText = ''){
				const dataType = 'application/vnd.ms-excel';
				const tableSelect = document.getElementById(transactionsTable);

				// Ensure tableSelect exists
				if (!tableSelect) {
					console.error('Table element not found');
					return;
				}
				
				// Add inline styles to ensure borders and padding
				const style = `
					<style>
						table, th, td {
							border: 1px solid gray;
							border-collapse: collapse;
						}
						th, td {
							padding: 5px;
							text-align: left;
						}
						
					</style>
				`;
				
				const headerHTML = headerText ? `<div class="header" >${headerText}</div>` : '';
    
				// Combine header and table HTML
				const tableHTML = style + headerHTML + tableSelect.outerHTML;

				// Specify file name
				filename = filename ? filename + '.xls' : 'excel_data.xls';
				
				// Create download link element
				const downloadLink = document.createElement('a');
				document.body.appendChild(downloadLink);

				if (navigator.msSaveOrOpenBlob) {
					// For IE and Edge
					const blob = new Blob(['\ufeff', tableHTML], { type: dataType });
					navigator.msSaveOrOpenBlob(blob, filename);
				} else {
					// For other browsers
					downloadLink.href = 'data:' + dataType + ', ' + encodeURIComponent(tableHTML);
					downloadLink.download = filename;
					
					// Trigger the download
					downloadLink.click();
				}
				
				// Clean up
				document.body.removeChild(downloadLink);
			},
			

			deleteSaleReturn(id){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
            }).then((result) => {
                if (result.isConfirmed) {
                    const formData = new FormData();
                    formData.append('id', id);
                    axios.post('post_url/del_sale_return',formData).then(res=>{

                        let r = res.data;
                      
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 3000
                        })
                        this.getSaleReturnRecord();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        },
        
			async print(){
				let dateText = '';
				if(this.dateFrom != '' && this.dateTo != ''){
					dateText = `Statement from <strong>${this.dateFrom}</strong> to <strong>${this.dateTo}</strong>`;
				}

				

				let supplierText = '';
				if(this.selectedSupplier != null && this.selectedSupplier.id != ''){
					supplierText = `<strong>Supplier: </strong> ${this.selectedSupplier.name}<br>`;
				}



				let reportContent = `
					<div class="container">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h3>Purchase Record</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								 ${supplierText} 
							</div>
							<div class="col-xs-6 text-right">
								${dateText}
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								${document.querySelector('#reportContent').innerHTML}
							</div>
						</div>
					</div>
				`;

				var reportWindow = window.open('', 'PRINT', `height=${screen.height}, width=${screen.width}`);
				reportWindow.document.write(`
                <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2"><img src="${this.campany.logo}" alt="Logo" style="height:80px;" /></div>
                        <div class="col-xs-10" style="padding-top:20px;">
                            <strong style="font-size:18px;">${this.campany.name}</strong><br>
                            <p style="white-space: pre-line;">${this.campany.address}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="border-bottom: 4px double #454545;margin-top:7px;margin-bottom:7px;"></div>
                        </div>
                    </div>
                </div>
            `);

				reportWindow.document.head.innerHTML += `
					<style>
						.record-table{
							width: 100%;
							border-collapse: collapse;
						}
						.record-table thead{
							background-color: #0097df;
							color:white;
						}
						.record-table th, .record-table td{
							padding: 3px;
							border: 1px solid #454545;
						}
						.record-table th{
							text-align: center;
						}
					</style>
				`;
				reportWindow.document.body.innerHTML += reportContent;

				if(this.searchType == '' || this.searchType == 'user'){
					let rows = reportWindow.document.querySelectorAll('.record-table tr');
					rows.forEach(row => {
						row.lastChild.remove();
					})
				}


				reportWindow.focus();
				await new Promise(resolve => setTimeout(resolve, 1000));
				reportWindow.print();
				reportWindow.close();
			}
		}
	})
</script>

<?php include('include/footer.php');?>