<?php 
$_SESSION['module'] = 'inventory';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];


$id = isset($_GET['id']) ? $_GET['id'] : '';
// var_dump($id);
// exit;
?>


<style>
	.v-select{
		margin-bottom: 5px;
	}
	.v-select.open .dropdown-toggle{
		border-bottom: 1px solid #ccc;
	}
	.v-select .dropdown-toggle{
		padding: 0px;
		height: 25px;
	}
	.v-select input[type=search], .v-select input[type=search]:focus{
		margin: 0px;
	}
	.v-select .vs__selected-options{
		overflow: hidden;
		flex-wrap:nowrap;
	}
	.v-select .selected-tag{
		margin: 2px 0px;
		white-space: nowrap;
		position:absolute;
		left: 0px;
	}
	.v-select .vs__actions{
		margin-top:-5px;
	}
	.v-select .dropdown-menu{
		width: auto;
		overflow-y:auto;
	}
	#products label{
		font-size:13px;
	}
	#products select{
		border-radius: 3px;
	}
	#products .add-button{
		padding: 2.5px;
		width: 28px;
		background-color: #298db4;
		display:block;
		text-align: center;
		color: white;
	}
	#products .add-button:hover{
		background-color: #41add6;
		color: white;
	}
</style>
<div class="row" id="sale">
        <div class="col-xs-12 col-md-3 col-lg-3" style="
    	padding: 0px;
		margin-bottom: 5px;
		">
		<div class="widget-box">
			<div class="widget-header">
				<h4 class="widget-title">Invoice Details</h4>
			
			</div>

			<div class="widget-body" style="background-color: #FFE7CE;">
				<div class="widget-main">
					<div class="row">
						<div class="col-xs-12">
							<div class="table-responsive">
								<table style="color:#000;margin-bottom: 0px;">
									<tr>
										<td style="width: 800px;">
											<div class="form-group">
												<label class="col-xs-4 control-label no-padding-right">Invoice no</label>
												<div class="col-xs-8">
													<input type="text" id="invoice" class="form-control" name="invoice" v-model="sale.invoice_number" readonly/>
												</div>
											</div>
										</td>
									</tr>

									<tr>
										<td>
											<div class="form-group">
												<label class="col-xs-4 control-label no-padding-right"> Date </label>
												<div class="col-xs-8">
													<input class="form-control" id="saleDate"  type="date" v-model="sale.order_date"/>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<label class="col-xs-4 control-label no-padding-right"> Customer </label>
                                            <div class="col-xs-7">
                                                <v-select v-bind:options="customers" style="width:100%" v-model="selectedCustomer" placeholder="Select Customer" label="display_text"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0;">
                                                <a href="/customer_entry" title="Add New Customer" class="btn btn-xs btn-danger" style="height: 25px; border: 0; width: 27px; margin-left: -10px;" target="_blank"><i class="fa fa-plus" aria-hidden="true" style="margin-top: 5px;"></i></a>
                                            </div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="form-group">
                                            <label class="col-xs-4 control-label no-padding-right"> Total Amount </label>
                                            <div class="col-xs-8">
                                                <input type="number"  id="total" class="form-control" v-model="sale.total" readonly />
                                            </div>
                                        </div>
										</td>
									</tr>
									<tr>
										<td>
                                            <div class="form-group">
                                                <div class="col-xs-6" style="padding-right:0px">
                                                </div>
												<div class="col-xs-6" style="padding-left:0px;display:flex">
													<input type="button" class="btn btn-success" value="Sale" v-on:click="save" v-bind:disabled="saleOnProgress == true ? true : false" style="background:#000;color:#fff;padding:0px;margin-right:5px;width:70%;">
                                                    <input type="button" class="btn btn-info" onclick="window.location = '/sale_inventory'" value="New Sale" style="background:#000;color:#fff;padding:0px;width:70%;">
												</div>
											</div>
										</td>
									</tr>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-xs-12 col-md-8 col-lg-8">
		<div class="widget-box">
			<div class="widget-header">
				<h5 class="widget-title">Product Information</h5>
			
			</div>

			<div class="widget-body" style="background-color: #AEE2FF;">
				<div class="widget-main">
					<div class="row">
						<div class="col-sm-12">
							<form v-on:submit.prevent="addToCart">
								<div class="form-group row">
									<label class="col-xs-2 control-label no-padding-right"> Product </label>
									<div class="col-xs-4">
                                        
										<v-select v-bind:options="products"  v-model="selectedProduct" label="display_text" @input="onChangeProduct()"></v-select>
									</div>
									<div class="col-xs-1" style="padding: 0;">
										<a href="/instrument_entry" title="Add New Product" class="btn btn-xs btn-danger" style="height: 25px; border: 0; width: 27px; margin-left: -10px;" target="_blank"><i class="fa fa-plus" aria-hidden="true" style="margin-top: 5px;"></i></a>
									</div>
                                    <label class="col-xs-2 control-label no-padding-right"> Sale Rate </label>
									<div class="col-xs-3">
										<input type="text" id="saleRate" class="form-control" placeholder="Sale Rate" v-model="selectedProduct.sale_price" v-on:input="productTotal" required/>
									</div>
								</div>


								<div class="form-group row">
									<label class="col-xs-2 control-label no-padding-right"> Quantity </label>
									<div class="col-xs-5">
										<input type="text" step="0.01" id="quantity" style="width:80%" name="quantity" class="form-control" placeholder="Quantity" ref="quantity" v-model="selectedProduct.quantity" v-on:input="productTotal" required/>
									</div>
									<label class="col-xs-2 control-label no-padding-right"> Total Amount </label>
									<div class="col-xs-3">
										<input type="text" id="productTotal" name="productTotal" class="form-control" readonly v-model="selectedProduct.total"/>
									</div>
								</div>

								<div class="form-group">
									
									<label class="col-xs-4 control-label no-padding-right"> </label>
									<div class="col-xs-8">
										<button type="submit" class="btn btn-default pull-right">Add Cart</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>


		<div class="col-xs-12 col-md-12 col-lg-12" style="padding-left: 0px;padding-right: 0px;">
			<div class="table-responsive">
				<table class="table table-bordered" style="color:#000;margin-bottom: 5px;">
					<thead>
						<tr style="background: #526D82;">
							<th style="width:4%;color:#fff;font-weight: 500">SL</th>
							<th style="width:20%;color:#fff;font-weight: 500">Product Name</th>
							<th style="width:8%;color:#fff;font-weight: 500">Sale Rate</th>
							<th style="width:5%;color:#fff;font-weight: 500">Quantity</th>
							<th style="width:13%;color:#fff;font-weight: 500">Total Amount</th>
							<th style="width:5%;color:#fff;font-weight: 500">Action</th>
						</tr>
					</thead>
					<tbody style="display:none;" v-bind:style="{display: cart.length > 0 ? '' : 'none'}">
						<tr v-for="(product, sl) in cart" :key="sl">
							<td>{{ sl + 1}}</td>
							<td>{{ product.name }}</td>
							<td>{{ product.sale_price }}</td>
							<td>{{ product.quantity }}</td>
							<td>{{ product.total }}</td>
							<td><a href="" v-on:click.prevent="removeFromCart(sl)"><i class="fa fa-trash"></i></a></td>
						</tr>

						<tr>
							<td colspan="7"></td>
						</tr>

						<tr style="font-weight: bold;">
							<td colspan="4">Note</td>
							<td colspan="3">Total</td>
						</tr>

						<tr>
							<td colspan="4"><textarea style="width: 100%;font-size:13px;" placeholder="Note" v-model="sale.note"></textarea></td>
							<td colspan="3" style="padding-top: 15px;font-size:18px;">{{ sale.total }}</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<div class="col-xs-12 col-sm-1 col-md-1" style="background-color: #acbac5;padding: 8px;border-radius: 5px;box-sizing:border-box;border:3px solid #fff;border-top-style: none;height:110px">
							
							<div>
								<div  style="display:none;text-align:center;" v-bind:style="{color: productStock > 0 ? 'green' : 'red', display: selectedProduct.id == '' ? 'none' : ''}">
													{{ productStockText }}
								</div>
								<input type="text" id="productStock"  v-model="productStock" readonly style="border:none;font-size:15px;width:100%;text-align:center;color:green;padding:3px;background: none !important;"><br>
							</div>
							<input type="password" ref="productPurchaseRate" v-model="selectedProduct.purchase_price" v-on:mousedown="toggleProductPurchaseRate" v-on:mouseup="toggleProductPurchaseRate"  readonly title="Purchase rate (click & hold)" style="font-size:12px;width:100%;text-align: center;">
	</div>

</div>


<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="assets/js/vue/vue-select.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	Vue.component('v-select', VueSelect.VueSelect);
	new Vue({
		el: '#sale',
		data(){
		
        return{
            sale: {
                id            : '<?php echo $id;?>',
                invoice_number: '',
                order_date    : moment().format('YYYY-MM-DD'),
                supplier_id   : '',
                total         : 0.00,
                note          : '',
                created_by    : '<?php echo $_SESSION['uid']?>'
            },
            
            customers: [],
            selectedCustomer: null,

            products: [],
            selectedProduct: {
                id            : '',
                display_text  : 'Select Product',
                name          : '',
                quantity      : '',
                purchase_price: '',
                total         : ''
            },
            cart               : [],
            saleOnProgress : false,
            productPurchaseRate: '',
            productStockText   : '',
            productStock       : '',
        }
    },
    async created(){
        await this.getSaleCode();
        await this.getCustomers();
        this.getProducts();
        if(this.sale.id != 0){
            this.getPurchase();
        }
    },
    methods:{
        
        async getCustomers(){
            await axios.get('post_url/get_customers').then(res => {
                this.customers = res.data;
            })
        },
        toggleProductPurchaseRate(){
				this.$refs.productPurchaseRate.type = this.$refs.productPurchaseRate.type == 'text' ? 'password' : 'text';
			},
        getSaleCode(){
            axios.get('post_url/get_sale_code').then(res=>{
                this.sale.invoice_number = res.data;
            })
        },
        getProducts(){
            axios.post('post_url/get_product').then(res=>{
                this.products = res.data;
            })
        },



        async onChangeProduct(){
          
            
				if (this.selectedProduct == null) {
					this.selectedProduct = {
						id            : '',
						display_text  : 'Select Product',
						name          : '',
						quantity      : '',
						purchase_price: '',
						sale_price	  : '',
						total         : ''
					};
					this.productPurchaseRate= '';
					this.productStockText= '';
					this.productStock= '';
					return true
				}



				if(this.selectedProduct !=null){
                    const formData = new FormData();
                    formData.append('id',this.selectedProduct.id);
					this.productStock = await axios.post('post_url/get_stock', formData).then(res => {
						return res.data;
						console.log(res.data);
					})
					this.productStockText = this.productStock > 0 ? "Available Stock" : "Stock Unavailable";
				}
				setTimeout(() =>{
				this.$refs.quantity.focus();
				}, 500);  
					
			},
        productTotal(){
            this.selectedProduct.total = this.selectedProduct.quantity * this.selectedProduct.sale_price;
        },
       
        addToCart(){
				
				let product = {
					productId     : this.selectedProduct.id,
					name          : this.selectedProduct.name,
					purchase_price: this.selectedProduct.purchase_price,
					sale_rate     : this.selectedProduct.sale_price,
					quantity      : this.selectedProduct.quantity,
					total         : this.selectedProduct.total
				}

				if(product.productId == ''){
					alert('Select Product');
					return;
				}

				if(product.quantity == 0 || product.quantity == ''){
					alert('Enter quantity');
					return;
				}

				if(product.sale_rate == 0 || product.sale_rate == ''){
					alert('Enter sales rate');
					return;
				}
				
				if(product.quantity > this.productStock){
					alert('Stock unavailable');
					return;
				}
				let cartInd = this.cart.findIndex(p => p.productId == product.productId);
				if(cartInd > -1){
					this.cart.splice(cartInd, 1);
				}

				this.cart.push(product);
				this.clearSelectedProduct();
				this.calculateTotal();
                
			},
			async removeFromCart(ind){
				
				this.cart.splice(ind, 1);
				this.calculateTotal();
			},
		clearSelectedProduct(){
				this.selectedProduct = {
					id            : '',
					display_text  : 'Select Product',
					name          : '',
					quantity      : '',
					purchase_price: '',
					sale_price    : '',
					total         : ''
				};
					this.productPurchaseRate= '';
					this.productStockText= '';
					this.productStock= '';
			},
		calculateTotal(){
				this.sale.total = this.cart.reduce((prev, curr) => { return prev + parseFloat(curr.total); }, 0).toFixed(2);
			},
    
        save(){

            if(this.selectedCustomer == null){
					alert('Select Customer');
					return;
            }

            if(this.sale.order_date == ''){
                alert('Enter Sale date');
                return;
            }

            if(this.cart.length == 0){
                alert('Cart is empty');
                return;
            }

            this.sale.customer_id      = this.selectedCustomer.id;

            this.saleOnProgress = true;

            // let data = {
            //     purchase: this.purchase,
            //     cartProducts: this.cart
            // }

            let url = 'post_url/store_sale';
            let quaryType = 'addSale';
            
            if(this.sale.id != 0){
                quaryType = 'updateSale';
            }
            let fd = new FormData();
            fd.append('sale', JSON.stringify(this.sale));
            fd.append('cartProducts', JSON.stringify(this.cart));
            fd.append('quaryType', JSON.stringify(quaryType));

          
            Swal.fire({
            title: '<strong>Are you sure!</strong>',
            html: '<strong>Want to Proccess this?</strong>',
            showDenyButton: true,
            confirmButtonText: `Ok`,
            denyButtonText: `Cancel`,
        }).then((result) => {
            if (result.isConfirmed) {
                axios.post(url, fd).then(async res=>{
                    let r = res.data;
                    Swal.fire({
                        icon: 'success',
                        title: r.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                    await new Promise(r => setTimeout(r, 1000));
                    
                    window.location = 'sales';
                    
                }).catch(error => {
                    let e = error.response.data;

                    if(e.hasOwnProperty('message')){
                        if(e.hasOwnProperty('errors')){
                            Object.entries(e.errors).forEach(([key, val])=>{
                                this.$toaster.error(val[0]);
                            })
                        }else{
                            this.$toaster.error(e.message);
                        }
                    }else{
                        this.$toaster.error(e);
                    }
                })
            }
        })


        },

     getPurchase(){

                    const formData = new FormData();
                    formData.append('id', this.sale.id);
                    formData.append('customer_id', '');
                    let with_details = true;
                    formData.append('with_details', with_details);
                


        axios.post('post_url/record_sale', formData).then(res => {
                let sale = res.data[0];
                console.log(sale);
                this.selectedCustomer = {
                    id           : sale.customer_id,
                    display_text : sale.display_name,
                    mobile       : sale.customer_mobile,
                    address      : sale.customer_address,
                }
                this.sale.invoice_number       = sale.invoice_number,
                this.sale.order_date           = sale.order_date;
                this.sale.customer_id          = sale.customer_id;
                this.sale.total                = sale.total;
                this.sale.note                 = sale.remark;

            sale.sale_details.forEach(item => {
                let cart = {
                id           : item.id,
                productId    : item.product_id,
                name         : item.product_name,
                quantity     : item.quantity,
                purchase_rate: item.purchase_rate,
                sale_rate    : item.sale_rate,
                total        : item.total_amount
                }
                this.cart.push(cart);
            })
            })
        }
    
    }
	})
</script>

<?php include('include/footer.php');?>