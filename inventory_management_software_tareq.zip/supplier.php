<?php 
$_SESSION['module'] = 'Administration';
$module = $_SESSION['module'];?>
<?php include('include/header.php'); ?>

<?php include('include/dashboard_style.php'); ?>

<?php
$cls_admin_users = new cls_admin_users();

$userID =  $_SESSION['uid'];

$CheckSuperAdmin =   $cls_admin_users->get_user($userID)->fetch_assoc();


$userAccessQuery =$cls_admin_users->get_permission($userID)->fetch_assoc();
$access = [];
if ($userAccessQuery != []) {
	$getPer = $userAccessQuery['permissions'];
	$getPer = preg_replace('/[^A-Za-z0-9\-\,\_]/', '', $getPer);
	$permissions =explode(',', $getPer);
	$access = $permissions;
}
$access = isset($access) && is_array($access) ? $access : [];
?>



    <div id='suppliers'>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">supplier  Entry</h5>
                        </div>

                        <div class="widget-body" style="background-color: #f1f1f1;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> supplier Code </label>
                                            <div class="col-xs-8">
                                                <input type="text" class="form-control" v-model="supplier.supplier_code" readonly />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> supplier Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="supplier Name" class="form-control" v-model="supplier.name" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Owner Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Owner Name" class="form-control" v-model="supplier.owner_name" />
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-6">

                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Phone </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Phone" class="form-control" v-model="supplier.mobile" required />
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Address </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Address" class="form-control" v-model="supplier.address"/>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Remark </label>
                                            <div class="col-xs-8">
                                                <input type="text"  placeholder="Remark"  class="form-control" v-model="supplier.remark"/>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="suppliers" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row }">
                            <tr class="hover-tr">
                                <td>{{ row.supplier_code }}</td>
                                <td>{{ row.name }}</td>
                                <td>{{ row.owner_name }}</td>
                                <td>{{ row.mobile }}</td>
                                <td>{{ row.address }}</td>
                                <td>{{ row.remark }}</td>
                                <td>
									<?php if($_SESSION['role'] !="General"){?>
                                        <a class="blue" href="javascript:" @click="editSupplier(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteSupplier(row)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
										<?php } ?>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>


<script src="assets/js/vue/vue.min.js"></script>
<script src="assets/js/vue/axios.min.js"></script>
<script src="assets/js/vue/vuejs-datatable.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	new Vue({
		el: '#suppliers',
		data () {
        return {
            supplier: {
                id           : '',
                supplier_code: '',
                name         : '',
                address      : '',
                mobile       : '',
                owner_name   : '',
                remark       : '',
                created_by   : '<?php echo $_SESSION['uid']?>',
            },

            suppliers      : [],

            columns: [
                { label: 'Supplier Code', field: 'supplier_code', align: 'center'},
                { label: 'Name', field: 'name', align: 'center' },
                { label: 'Owner Name', field: 'owner_name', align: 'center' },
                { label: 'Phone', field: 'mobile', align: 'center' },
                { label: 'address', field: 'address', align: 'center' },
                { label: 'Remark', field: 'remark', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getSupplier();
        this.getsupplierCode();
    },
    methods: {

        getSupplier(){
            axios.get('post_url/get_suppliers').then(res=>{
                this.suppliers = res.data;
				
            })
        },

        getsupplierCode(){
            axios.get('post_url/get_supplier_code').then(res=>{
                this.supplier.supplier_code = res.data;
            })
        },
        save(){
            this.progress = true;


            let url = 'post_url/store_supplier';
            let quaryType = 'addsupplier';

            if(this.supplier.id != ''){
                 quaryType = 'updatesupplier';
            }
           
            let fd = new FormData();
            fd.append('suppliers', JSON.stringify(this.supplier));
            fd.append('quaryType', JSON.stringify(quaryType));
            axios.post(url, fd).then(res=>{
                console.log(res.data);
                    this.progress = false;
                    alert(res.data.message);
					if(res.data.success){
                        this.progress = false;
                        this.clear();
                        this.getsupplierCode();
                        this.getSupplier();
					}else{
                        this.progress = false;
                    }
  
            })
        },
        clear(){
        
            this.supplier = {
                id             : '',
                name         : '',
                address      : '',
                mobile       : '',
                owner_name   : '',
                remark       : '',
                created_by   : '<?php echo $_SESSION['uid']?>',
            };
        },
        
     
        editSupplier(row){

            this.supplier = {
                id           : row.id,
                supplier_code: row.supplier_code,
                name         : row.name,
                address      : row.address,
                mobile       : row.mobile,
                owner_name   : row.owner_name,
                remark       : row.remark,
                created_by   :  '<?php echo $_SESSION['uid']?>',
            }

        },
        deleteSupplier(data){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
                }).then((result) => {
                if (result.isConfirmed) {
                    let fd = new FormData();
                    fd.append('data', JSON.stringify(data));
            
                    axios.post('post_url/del_supplier', fd).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getsupplierCode();
                        this.getSupplier();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
	})
</script>

<?php include('include/footer.php');?>